import React, { createContext, useContext, useState, useEffect } from 'react';
import enTranslations from '../locales/en.json';
import arTranslations from '../locales/ar.json';

type Locale = 'en' | 'ar';

interface TranslationContextType {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: (key: string) => string;
  dir: 'ltr' | 'rtl';
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

const translations: Record<Locale, any> = {
  en: enTranslations,
  ar: arTranslations,
};

export const TranslationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [locale, setLocaleState] = useState<Locale>(() => {
    // Detect from localStorage first
    const saved = localStorage.getItem('gta-vi-hub-locale');
    if (saved === 'en' || saved === 'ar') return saved;

    // Detect browser language
    try {
      const browserLang = navigator.language || (navigator as any).userLanguage;
      if (browserLang && browserLang.startsWith('ar')) {
        return 'ar';
      }
    } catch (e) {
      // Ignore fallback errors
    }

    return 'en';
  });

  const setLocale = (newLocale: Locale) => {
    setLocaleState(newLocale);
    localStorage.setItem('gta-vi-hub-locale', newLocale);
  };

  useEffect(() => {
    // Update document language and direction for true native accessibility and RTL spacing
    const dir = locale === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.dir = dir;
    document.documentElement.lang = locale;
    
    // Add specific class for extra RTL spacing adjustments
    if (locale === 'ar') {
      document.documentElement.classList.add('rtl-active');
    } else {
      document.documentElement.classList.remove('rtl-active');
    }
  }, [locale]);

  // Deep key resolver t('header.home') with English fallback if Arabic is missing
  const t = (key: string): string => {
    const keys = key.split('.');
    
    // Try current locale
    let currentObj = translations[locale];
    let found = true;
    for (const k of keys) {
      if (currentObj && typeof currentObj === 'object' && k in currentObj) {
        currentObj = currentObj[k];
      } else {
        found = false;
        break;
      }
    }

    if (found && typeof currentObj === 'string') {
      return currentObj;
    }

    // Fallback to English
    let fallbackObj = translations['en'];
    let fallbackFound = true;
    for (const k of keys) {
      if (fallbackObj && typeof fallbackObj === 'object' && k in fallbackObj) {
        fallbackObj = fallbackObj[k];
      } else {
        fallbackFound = false;
        break;
      }
    }

    if (fallbackFound && typeof fallbackObj === 'string') {
      return fallbackObj;
    }

    // Return key if nothing found
    return key;
  };

  const dir = locale === 'ar' ? 'rtl' : 'ltr';

  return (
    <TranslationContext.Provider value={{ locale, setLocale, t, dir }}>
      {children}
    </TranslationContext.Provider>
  );
};

export const useTranslation = () => {
  const context = useContext(TranslationContext);
  if (!context) {
    throw new Error('useTranslation must be used within a TranslationProvider');
  }
  return context;
};
