import React, { useState, useEffect } from 'react';

interface OptimizedImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  src: string;
  alt: string;
  className?: string;
  aspectRatio?: 'video' | 'square' | 'wide' | 'auto' | 'portrait';
  priority?: boolean;
}

export default function OptimizedImage({
  src,
  alt,
  className = '',
  aspectRatio = 'auto',
  priority = false,
  ...props
}: OptimizedImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);

  // Reset state when source changes
  useEffect(() => {
    setIsLoaded(false);
    setError(false);
  }, [src]);

  const aspectClasses = {
    video: 'aspect-video',
    square: 'aspect-square',
    wide: 'aspect-[21/9]',
    portrait: 'aspect-[3/4]',
    auto: 'h-auto w-full'
  };

  return (
    <div className={`relative overflow-hidden bg-zinc-950 border border-white/5 ${aspectClasses[aspectRatio]} ${className}`}>
      {/* Loading Skeleton */}
      {!isLoaded && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-zinc-900 animate-pulse">
          <div className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest flex items-center space-x-1.5">
            <span className="w-1.5 h-1.5 bg-pink-500 rounded-full animate-ping" />
            <span>Loading Telemetry Image...</span>
          </div>
        </div>
      )}

      {/* Error fallback */}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-zinc-950 p-4 border border-red-500/10 text-center">
          <span className="text-[9px] font-mono text-red-500 font-bold uppercase tracking-wider mb-1">Signal Dropped</span>
          <span className="text-[10px] font-sans text-zinc-500 truncate max-w-full">{alt}</span>
        </div>
      )}

      {/* Actual Image */}
      <img
        src={src}
        alt={alt}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        referrerPolicy="no-referrer"
        onLoad={() => setIsLoaded(true)}
        onError={() => {
          setIsLoaded(true);
          setError(true);
        }}
        className={`w-full h-full object-cover transition-opacity duration-500 ease-out ${
          isLoaded && !error ? 'opacity-100' : 'opacity-0'
        }`}
        {...props}
      />
    </div>
  );
}
