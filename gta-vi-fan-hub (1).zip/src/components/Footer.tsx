import { ViewType } from '../types';
import { ShieldAlert, Globe, Github, Twitter, Youtube, ArrowUpRight, ShieldCheck, HelpCircle, Heart, Zap } from 'lucide-react';
import { useTranslation } from '../context/TranslationContext';

interface FooterProps {
  setView: (view: ViewType) => void;
}

export default function Footer({ setView }: FooterProps) {
  const { t, locale, setLocale } = useTranslation();
  
  const handleScrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full border-t border-white/10 bg-black text-zinc-400 relative overflow-hidden" id="footer-main">
      {/* Aesthetic grid backdrop inside footer */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#111115_1px,transparent_1px),linear-gradient(to_bottom,#111115_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] pointer-events-none opacity-30" />
      
      {/* Subtle top indicator line */}
      <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-pink-500/40 to-transparent" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        
        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-12 border-b border-white/5">
          
          {/* Brand block (5 cols) */}
          <div className="md:col-span-5 space-y-5">
            <div className="flex items-center space-x-2">
              <span className="font-display font-black tracking-tighter text-2xl text-white uppercase block">
                GTA <span className="bg-gradient-to-r from-pink-500 to-orange-400 bg-clip-text text-transparent">VI</span> HUB
              </span>
              <span className="font-mono text-[8px] border border-pink-500/30 px-2 py-0.5 text-pink-400 uppercase tracking-widest font-black bg-pink-500/5">
                VER 2.6
              </span>
            </div>
            <p className="text-sm text-zinc-400 max-w-sm leading-relaxed font-sans">
              {t('footer.brand_desc')}
            </p>
            
            <div className="pt-2 flex flex-wrap gap-2 text-xs font-mono">
              <div className="flex items-center gap-1 bg-zinc-950/80 px-2.5 py-1.5 border border-white/5 text-zinc-500">
                <ShieldCheck className="h-3 w-3 text-pink-500" />
                <span>{t('footer.consensus_audited')}</span>
              </div>
              <div className="flex items-center gap-1 bg-zinc-950/80 px-2.5 py-1.5 border border-white/5 text-zinc-500">
                <Zap className="h-3 w-3 text-orange-400" />
                <span>{t('footer.zero_latency')}</span>
              </div>
            </div>
          </div>

          {/* Quick links directory (4 cols) */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="text-white font-display font-black text-xs tracking-widest uppercase flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-pink-500 block" />
              <span>{t('footer.sitemap')}</span>
            </h4>
            <div className="grid grid-cols-2 gap-x-6 gap-y-2.5 text-xs text-zinc-500 font-sans">
              <button onClick={() => { setView('home'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('header.home')}</button>
              <button onClick={() => { setView('news'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('header.news')}</button>
              <button onClick={() => { setView('ai-news'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium text-pink-500 hover:text-pink-400 hover:translate-x-1 rtl:hover:-translate-x-1 transition-all font-bold cursor-pointer">{t('header.ai_news')}</button>
              <button onClick={() => { setView('database'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('nav.vehicles')}</button>
              <button onClick={() => { setView('map'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('header.map')}</button>
              <button onClick={() => { setView('characters'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('header.protagonists')}</button>
              <button onClick={() => { setView('leaks'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('nav.leaks')}</button>
              <button onClick={() => { setView('gallery'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('nav.gallery')}</button>
              <button onClick={() => { setView('videos'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('nav.videos')}</button>
              <button onClick={() => { setView('leaderboard'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('nav.leaderboard')}</button>
              <button onClick={() => { setView('faq'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('nav.faq')}</button>
              <button onClick={() => { setView('search'); handleScrollToTop(); }} className="text-left rtl:text-right font-medium hover:text-white hover:translate-x-1 rtl:hover:-translate-x-1 transition-all cursor-pointer">{t('nav.search')}</button>
            </div>
          </div>

          {/* Social connections & Action (3 cols) */}
          <div className="md:col-span-3 space-y-4 text-left rtl:text-right">
            <h4 className="text-white font-display font-black text-xs tracking-widest uppercase flex items-center gap-2">
              <span className="h-1.5 w-1.5 bg-orange-500 block" />
              <span>{t('footer.leonida_wave')}</span>
            </h4>
            <p className="text-xs text-zinc-500 leading-normal font-sans">
              {t('footer.social_desc')}
            </p>
            <div className="flex flex-wrap gap-2 pt-1">
              {[
                { Icon: Twitter, href: 'https://twitter.com', color: 'hover:text-cyan-400 hover:border-cyan-400/50 hover:bg-cyan-400/5' },
                { Icon: Youtube, href: 'https://youtube.com', color: 'hover:text-red-500 hover:border-red-500/50 hover:bg-red-500/5' },
                { Icon: Github, href: 'https://github.com', color: 'hover:text-purple-400 hover:border-purple-400/50 hover:bg-purple-400/5' },
                { Icon: Globe, href: 'https://google.com', color: 'hover:text-pink-400 hover:border-pink-400/50 hover:bg-pink-400/5' }
              ].map((social, sIdx) => (
                <a 
                  key={sIdx}
                  href={social.href} 
                  target="_blank" 
                  rel="noreferrer" 
                  className={`border border-white/10 p-2.5 text-zinc-400 rounded-none transition-all duration-200 ${social.color}`}
                >
                  <social.Icon className="h-4.5 w-4.5" />
                </a>
              ))}
            </div>
            <button 
              onClick={handleScrollToTop}
              className="group flex items-center gap-1.5 text-[10px] font-mono text-zinc-500 hover:text-pink-400 transition-colors uppercase tracking-widest cursor-pointer"
            >
              <span>{t('footer.back_to_top')}</span>
              <ArrowUpRight className="h-3 w-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 rtl:group-hover:-translate-x-0.5 rtl:group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>
        </div>

        {/* Disclaimer section */}
        <div className="pt-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 text-xs text-zinc-600 font-sans">
          <div className="flex items-start gap-2.5">
            <ShieldAlert className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
            <p className="max-w-3xl leading-relaxed text-[11px] text-left rtl:text-right">
              <span className="font-bold text-zinc-500 uppercase font-mono text-[9px] tracking-wider block mb-0.5">{t('footer.disclaimer_title')}</span>
              {locale === 'ar' ? (
                <>هذا الموقع عبارة عن تطبيق تفاعلي غير رسمي ومجاني بنسبة 100% تم إنشاؤه من قبل المعجبين. جميع مفاهيم اللعبة والملكيات الفكرية والمقاطع الدعائية ولقطات الشاشة وأصول الوسائط ذات الصلة هي حقوق طبع ونشر لـ <a href="https://www.rockstargames.com" className="hover:underline text-zinc-500 font-semibold hover:text-pink-500">Rockstar Games</a> و <a href="https://www.take2games.com" className="hover:underline text-zinc-500 font-semibold hover:text-pink-500">Take-Two Interactive</a>. لا يقصد أي انتهاك لحقوق الطبع والنشر بأي شكل من الأشكال.</>
              ) : (
                <>This website is a 100% unofficial, non-profit, fan-made interactive application. All game concepts, intellectual property, trailers, screen captures, and related media assets are copyright of <a href="https://www.rockstargames.com" className="hover:underline text-zinc-500 font-semibold hover:text-pink-500">Rockstar Games</a> and <a href="https://www.take2games.com" className="hover:underline text-zinc-500 font-semibold hover:text-pink-500">Take-Two Interactive</a>. No copyright infringement is intended in any form.</>
              )}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            {/* Footer Language Switcher */}
            <div className="flex items-center border border-white/10 bg-zinc-950 px-1 py-0.5 select-none text-[9px]">
              <button
                onClick={() => setLocale('en')}
                className={`px-2 py-0.5 font-display font-black uppercase transition-all duration-150 cursor-pointer ${
                  locale === 'en'
                    ? 'bg-gradient-to-r from-pink-500 to-orange-400 text-black font-extrabold shadow-[0_0_5px_rgba(236,72,153,0.3)]'
                    : 'text-zinc-600 hover:text-white'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLocale('ar')}
                className={`px-2 py-0.5 font-display font-black uppercase transition-all duration-150 cursor-pointer ${
                  locale === 'ar'
                    ? 'bg-gradient-to-r from-pink-500 to-orange-400 text-black font-extrabold shadow-[0_0_5px_rgba(236,72,153,0.3)]'
                    : 'text-zinc-600 hover:text-white'
                }`}
              >
                العربية
              </button>
            </div>

            <span className="shrink-0 font-mono text-[9px] tracking-widest uppercase text-zinc-600 font-bold bg-zinc-950 px-2 py-1 border border-white/5">
              © {new Date().getFullYear()} GTA VI Fan Hub Inc.
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
