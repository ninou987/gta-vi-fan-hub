import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu, X, Clock, Compass, Users, Database, Newspaper, Film, Award, 
  ChevronDown, Lock, Image as ImageIcon, HelpCircle, Search, Info, Car, Skull, ShieldCheck, Brain,
  Bell, Trophy, User, Trash2, CheckSquare, Sliders, Cpu, Radio, BarChart2, Languages
} from 'lucide-react';
import { ViewType } from '../types';
import { useCommunity } from '../context/CommunityContext';
import { useTranslation } from '../context/TranslationContext';

interface HeaderProps {
  currentView: ViewType;
  setView: (view: ViewType) => void;
  setSelectedDatabaseTab?: (tab: 'vehicle' | 'weapon') => void;
}

export default function Header({ currentView, setView, setSelectedDatabaseTab }: HeaderProps) {
  const { t, locale, setLocale, dir } = useTranslation();
  const { notifications, markNotificationAsRead, clearAllNotifications } = useCommunity();
  const [isOpen, setIsOpen] = useState(false);
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isPreorderOpen, setIsPreorderOpen] = useState(false);
  const [preorderPlatform, setPreorderPlatform] = useState<'ps5' | 'xbox'>('ps5');
  const [preorderEdition, setPreorderEdition] = useState<'standard' | 'deluxe' | 'collector'>('standard');
  const [preorderSuccess, setPreorderSuccess] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  // Count unread alerts
  const unreadCount = notifications.filter(n => !n.read).length;

  // Calculate live countdown to speculated release: November 17, 2026
  useEffect(() => {
    const targetDate = new Date('2026-11-17T00:00:00').getTime();

    const calculateTime = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // Close notifications if clicked outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setIsNotifOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Primary top navigation items (highly visible)
  const primaryNavItems = [
    { id: 'home', label: t('header.home'), icon: Award },
    { id: 'characters', label: t('header.protagonists'), icon: Users },
    { id: 'map', label: t('header.map'), icon: Compass },
    { id: 'news', label: t('header.news'), icon: Newspaper },
    { id: 'ai-news', label: t('header.ai_news'), icon: Brain },
  ] as const;

  // Dropdown "More Intel" items for remaining pages
  const moreNavItems = [
    { id: 'vehicles', label: t('nav.vehicles'), icon: Car, action: () => { setSelectedDatabaseTab?.('vehicle'); setView('database'); } },
    { id: 'weapons', label: t('nav.weapons'), icon: Skull, action: () => { setSelectedDatabaseTab?.('weapon'); setView('database'); } },
    { id: 'leaks', label: t('nav.leaks'), icon: Lock, action: () => { setView('leaks'); } },
    { id: 'gallery', label: t('nav.gallery'), icon: ImageIcon, action: () => { setView('gallery'); } },
    { id: 'videos', label: t('nav.videos'), icon: Film, action: () => { setView('videos'); } },
    { id: 'trust-legend', label: t('nav.trust_legend'), icon: ShieldCheck, action: () => { setView('trust-legend'); } },
    { id: 'faq', label: t('nav.faq'), icon: HelpCircle, action: () => { setView('faq'); } },
    { id: 'search', label: t('nav.search'), icon: Search, action: () => { setView('search'); } },
    { id: 'about', label: t('nav.about'), icon: Info, action: () => { setView('about'); } },
    { id: 'profile', label: t('nav.profile'), icon: User, action: () => { setView('profile'); } },
    { id: 'leaderboard', label: t('nav.leaderboard'), icon: Trophy, action: () => { setView('leaderboard'); } },
    { id: 'settings', label: t('nav.settings'), icon: Sliders, action: () => { setView('settings'); } },
    { id: 'ai-dashboard', label: t('nav.ai_dashboard'), icon: Brain, action: () => { setView('ai-dashboard'); } },
    { id: 'ai-system', label: t('nav.ai_system'), icon: Cpu, action: () => { setView('ai-system'); } },
    { id: 'sources', label: t('nav.sources'), icon: Radio, action: () => { setView('sources'); } },
    { id: 'analytics', label: t('nav.analytics'), icon: BarChart2, action: () => { setView('analytics'); } },
    { id: 'admin', label: t('nav.admin'), icon: Sliders, action: () => { setView('admin'); } },
  ];

  const handleNavClick = (viewId: ViewType) => {
    setView(viewId);
    setIsOpen(false);
    setIsMoreOpen(false);
    setIsNotifOpen(false);
  };

  const handleMoreClick = (item: typeof moreNavItems[number]) => {
    item.action();
    setIsOpen(false);
    setIsMoreOpen(false);
    setIsNotifOpen(false);
  };

  const handleNotifClick = (id: string) => {
    markNotificationAsRead(id);
    setView('profile');
    setIsNotifOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-[#050505]/95 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo Section */}
        <div 
          onClick={() => handleNavClick('home')} 
          className="flex cursor-pointer items-center space-x-2 select-none group"
          id="nav-logo"
        >
          <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-orange-400 rounded-none flex items-center justify-center font-display font-black text-lg text-black shadow-[0_0_15px_rgba(236,72,153,0.3)] group-hover:scale-105 transition-transform">VI</div>
          <span className="font-display font-black tracking-tighter text-lg ml-2 text-white uppercase">
            GTA <span className="bg-gradient-to-r from-pink-500 to-orange-400 bg-clip-text text-transparent">VI</span> HUB
          </span>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center space-x-1" id="desktop-nav">
          {primaryNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`relative flex items-center space-x-2 px-4 py-2 text-xs font-display font-black uppercase tracking-wider transition-colors select-none ${
                  isActive ? 'text-pink-500' : 'text-zinc-400 hover:text-white'
                }`}
                id={`nav-${item.id}`}
              >
                {isActive && (
                  <motion.div
                    layoutId="active-tab"
                    className="absolute inset-x-0 bottom-0 h-0.5 bg-gradient-to-r from-pink-500 to-orange-400"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
                <Icon className="h-3.5 w-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}

          {/* "More Intel" Custom Hover Dropdown */}
          <div 
            className="relative"
            onMouseEnter={() => setIsMoreOpen(true)}
            onMouseLeave={() => setIsMoreOpen(false)}
          >
            <button
              className={`flex items-center gap-1 px-4 py-2 text-xs font-display font-black uppercase tracking-wider transition-colors select-none ${
                isMoreOpen || ['database', 'leaks', 'breakdown', 'gallery', 'videos', 'trust-legend', 'faq', 'search', 'about', 'profile', 'leaderboard'].includes(currentView)
                  ? 'text-pink-500' 
                  : 'text-zinc-400 hover:text-white'
              }`}
            >
              <span>{t('header.more_intel')}</span>
              <ChevronDown className={`h-3.5 w-3.5 transition-transform duration-200 ${isMoreOpen ? 'rotate-180' : ''}`} />
            </button>

            <AnimatePresence>
              {isMoreOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 5 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 mt-0 w-56 bg-black border border-white/10 p-2 shadow-2xl space-y-0.5"
                >
                  {moreNavItems.map((item) => {
                    const Icon = item.icon;
                    // Check active status
                    const isActive = currentView === item.id || 
                      (item.id === 'vehicles' && currentView === 'database') || 
                      (item.id === 'weapons' && currentView === 'database');
                    
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleMoreClick(item)}
                        className={`w-full flex items-center space-x-3 px-3 py-2.5 text-left text-xs font-display font-black uppercase tracking-wider transition-colors rounded-none ${
                          isActive 
                            ? 'bg-pink-500/10 text-pink-500 border-l-2 border-pink-500' 
                            : 'text-zinc-400 hover:text-white hover:bg-white/5'
                        }`}
                      >
                        <Icon className="h-4 w-4 shrink-0" />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </nav>

        {/* Right Section: Ticker + Notification Bell */}
        <div className="hidden sm:flex items-center gap-4 border-l rtl:border-l-0 rtl:border-r border-white/10 pl-6 rtl:pl-0 rtl:pr-6" id="header-countdown-ticker">
          
          {/* Language Switcher */}
          <div className="flex items-center border border-white/10 bg-zinc-950 px-1 py-0.5 select-none">
            <button
              onClick={() => setLocale('en')}
              className={`px-2 py-1 text-[10px] font-display font-black uppercase transition-all duration-150 cursor-pointer ${
                locale === 'en'
                  ? 'bg-gradient-to-r from-pink-500 to-orange-400 text-black font-extrabold shadow-[0_0_10px_rgba(236,72,153,0.3)]'
                  : 'text-zinc-500 hover:text-white'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLocale('ar')}
              className={`px-2 py-1 text-[10px] font-display font-black uppercase transition-all duration-150 cursor-pointer ${
                locale === 'ar'
                  ? 'bg-gradient-to-r from-pink-500 to-orange-400 text-black font-extrabold shadow-[0_0_10px_rgba(236,72,153,0.3)]'
                  : 'text-zinc-500 hover:text-white'
              }`}
            >
              العربية
            </button>
          </div>

          {/* INTERACTIVE NOTIFICATION BELL CENTER (Requirement: Notification center UI) */}
          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setIsNotifOpen(!isNotifOpen)}
              className={`p-2 transition-colors relative hover:text-white border border-white/5 bg-zinc-950 cursor-pointer ${
                unreadCount > 0 ? 'text-pink-500' : 'text-zinc-400'
              }`}
              id="desktop-notif-bell"
            >
              <Bell className={`h-4 w-4 ${unreadCount > 0 ? 'animate-pulse' : ''}`} />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-pink-600 text-black text-[9px] font-mono font-black h-4 w-4 flex items-center justify-center select-none animate-bounce">
                  {unreadCount}
                </span>
              )}
            </button>

            {/* Float notification mini card drawer */}
            <AnimatePresence>
              {isNotifOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-80 bg-black border border-white/10 p-4 shadow-2xl space-y-3 z-50 text-left rtl:text-right"
                >
                  <div className="flex justify-between items-center pb-2 border-b border-white/5 gap-2">
                    <span className="text-[10px] font-mono font-black text-zinc-400 uppercase tracking-widest">{t('header.stream_alerts')}</span>
                    {notifications.length > 0 && (
                      <button 
                        onClick={clearAllNotifications}
                        className="text-[9px] font-mono text-zinc-500 hover:text-red-400 flex items-center gap-1 cursor-pointer"
                      >
                        <Trash2 className="h-3 w-3" />
                        <span>{t('header.clear')}</span>
                      </button>
                    )}
                  </div>

                  {notifications.length === 0 ? (
                    <div className="py-6 text-center text-zinc-500 font-sans text-xs">
                      {t('header.no_alerts')}
                    </div>
                  ) : (
                    <div className="space-y-2.5 max-h-60 overflow-y-auto pr-1 pl-1">
                      {notifications.slice(0, 3).map(notif => (
                        <div 
                          key={notif.id}
                          onClick={() => handleNotifClick(notif.id)}
                          className={`p-2.5 border text-xs cursor-pointer hover:bg-zinc-950 transition-colors ${
                            notif.read ? 'border-white/5 text-zinc-500' : 'border-pink-500/20 bg-pink-500/5 text-white'
                          }`}
                        >
                          <div className="flex justify-between items-baseline font-mono text-[9px] font-bold text-pink-400 uppercase gap-2">
                            <span>{notif.title}</span>
                            <span className="text-zinc-600 text-[8px]">{notif.timestamp}</span>
                          </div>
                          <p className="mt-0.5 leading-snug text-[11px] font-sans text-zinc-400 truncate">
                            {notif.message}
                          </p>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="border-t border-white/5 pt-2 flex justify-between items-center">
                    <button
                      onClick={() => { setView('profile'); setIsNotifOpen(false); }}
                      className="w-full text-center py-1 bg-white/5 hover:bg-pink-600 hover:text-black font-mono font-black text-[10px] text-zinc-400 uppercase transition-all select-none cursor-pointer"
                    >
                      {t('header.inspect_profile')} ({notifications.length})
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-pink-500 font-mono text-[10px] tracking-wider uppercase font-black px-2.5 py-1 bg-pink-500/10 border border-pink-500/20 animate-pulse">
              {t('header.preorder_active')}
            </span>
            <button 
              onClick={() => {
                setPreorderSuccess(false);
                setIsPreorderOpen(true);
              }}
              className="bg-gradient-to-r from-pink-500 to-orange-400 text-black font-display font-black text-[10px] uppercase tracking-wider px-3.5 py-1.5 hover:opacity-90 hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer"
            >
              {t('header.preorder_alerts')}
            </button>
          </div>

        </div>

        {/* Mobile menu button */}
        <div className="flex lg:hidden items-center space-x-2">
          
          {/* Mobile notification bell link */}
          <button
            onClick={() => setView('profile')}
            className={`p-2 relative border border-white/5 bg-zinc-950 ${
              unreadCount > 0 ? 'text-pink-500' : 'text-zinc-500'
            }`}
            id="mobile-notif-bell"
          >
            <Bell className="h-4 w-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-pink-600 text-black text-[8px] font-mono font-black h-3.5 w-3.5 flex items-center justify-center rounded-none">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Pre-order badge for mobile screens */}
          <button 
            onClick={() => {
              setPreorderSuccess(false);
              setIsPreorderOpen(true);
            }}
            className="flex items-center bg-pink-600 hover:bg-pink-500 text-black font-display font-black text-[9px] uppercase tracking-wider px-2.5 py-1.5 transition-colors sm:hidden cursor-pointer"
          >
            {t('header.preorder_alerts')}
          </button>

          <button
            onClick={() => setIsOpen(!isOpen)}
            className="inline-flex items-center justify-center p-2 text-zinc-400 hover:bg-zinc-900 hover:text-white focus:outline-none"
            id="mobile-menu-btn"
          >
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Drawer (Exhaustive, thumb-friendly list) */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="border-b border-white/10 bg-[#050505] lg:hidden overflow-hidden"
            id="mobile-drawer"
          >
            <div className="space-y-1 px-2 pt-2 pb-4 max-h-[75vh] overflow-y-auto">
              {/* Language Switcher for mobile */}
              <div className="flex items-center justify-between px-3 py-2 bg-zinc-900/50 border border-white/5 mb-3 rounded-none">
                <span className="text-[10px] font-mono font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-1.5">
                  <Languages className="h-3 w-3" />
                  Language / اللغة
                </span>
                <div className="flex items-center border border-white/10 bg-black px-1 py-0.5 select-none">
                  <button
                    onClick={() => setLocale('en')}
                    className={`px-2 py-0.5 text-[9px] font-display font-black uppercase transition-all duration-150 cursor-pointer ${
                      locale === 'en'
                        ? 'bg-gradient-to-r from-pink-500 to-orange-400 text-black font-extrabold shadow-[0_0_5px_rgba(236,72,153,0.3)]'
                        : 'text-zinc-400'
                    }`}
                  >
                    EN
                  </button>
                  <button
                    onClick={() => setLocale('ar')}
                    className={`px-2 py-0.5 text-[9px] font-display font-black uppercase transition-all duration-150 cursor-pointer ${
                      locale === 'ar'
                        ? 'bg-gradient-to-r from-pink-500 to-orange-400 text-black font-extrabold shadow-[0_0_5px_rgba(236,72,153,0.3)]'
                        : 'text-zinc-400'
                    }`}
                  >
                    العربية
                  </button>
                </div>
              </div>

              {/* Primary list */}
              {primaryNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`flex w-full items-center space-x-3 px-4 py-3 text-sm font-display font-bold uppercase tracking-wider transition-colors ${
                      isActive 
                        ? 'bg-pink-500/10 border-l-4 border-pink-500 text-pink-400' 
                        : 'text-zinc-400 hover:bg-zinc-900 hover:text-white'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}

              {/* Sub list */}
              <div className="border-t border-white/5 my-2 pt-2">
                <span className="px-4 text-[10px] font-mono text-zinc-500 uppercase tracking-widest block mb-1">{t('header.more_intel')}</span>
                {moreNavItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = currentView === item.id || 
                    (item.id === 'vehicles' && currentView === 'database') || 
                    (item.id === 'weapons' && currentView === 'database');
                  return (
                    <button
                      key={item.id}
                      onClick={() => handleMoreClick(item)}
                      className={`flex w-full items-center space-x-3 px-4 py-2.5 text-xs font-display font-bold uppercase tracking-wider transition-colors ${
                        isActive 
                          ? 'bg-pink-500/5 border-l-2 border-pink-500 text-pink-400' 
                          : 'text-zinc-500 hover:bg-zinc-900 hover:text-zinc-300'
                      }`}
                    >
                      <Icon className="h-3.5 w-3.5" />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Mobile drawer pre-order block */}
              <div className="mx-4 mt-4 flex flex-col gap-2.5 bg-zinc-900 p-3 border border-zinc-800">
                <div className="flex items-center space-x-2">
                  <span className="inline-block h-2 w-2 rounded-full bg-pink-500 animate-pulse" />
                  <span className="text-zinc-300 font-mono text-[10px] uppercase font-bold">{t('header.preorder_active')}</span>
                </div>
                <button 
                  onClick={() => {
                    setPreorderSuccess(false);
                    setIsPreorderOpen(true);
                    setIsOpen(false);
                  }}
                  className="w-full bg-gradient-to-r from-pink-500 to-orange-400 text-black font-display font-black text-xs uppercase tracking-wider py-2.5 text-center hover:opacity-90 transition-opacity cursor-pointer"
                >
                  {t('header.preorder_alerts')}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isPreorderOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md" id="preorder-modal-container">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-lg bg-zinc-950 border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl text-left"
              id="preorder-modal-card"
            >
              <button
                onClick={() => setIsPreorderOpen(false)}
                className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1"
                id="preorder-close-btn"
              >
                <X className="h-5 w-5" />
              </button>

              {!preorderSuccess ? (
                <div className="space-y-6">
                  <div>
                    <span className="text-pink-500 font-mono text-[9px] tracking-widest uppercase font-black block mb-1">
                      {t('header.preorder_title')}
                    </span>
                    <h2 className="text-2xl font-display font-black text-white uppercase tracking-tight">
                      Grand Theft Auto VI
                    </h2>
                    <p className="text-zinc-400 text-xs mt-1 font-sans">
                      {t('header.preorder_desc')}
                    </p>
                  </div>

                  {/* Platform Selection */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">
                      {t('header.select_platform')}
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { id: 'ps5', label: 'PlayStation 5' },
                        { id: 'xbox', label: 'Xbox Series X|S' }
                      ].map(plat => (
                        <button
                          key={plat.id}
                          onClick={() => setPreorderPlatform(plat.id as any)}
                          className={`p-3 text-xs font-mono font-black uppercase border text-center transition-all ${
                            preorderPlatform === plat.id
                              ? 'border-pink-500 bg-pink-500/10 text-pink-500'
                              : 'border-white/5 bg-black text-zinc-400 hover:text-white hover:bg-white/5'
                          }`}
                        >
                          {plat.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Edition Selection */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">
                      {t('header.select_edition')}
                    </label>
                    <div className="space-y-2">
                      {[
                        { id: 'standard', label: t('header.standard'), price: '$69.99', desc: locale === 'ar' ? 'اللعبة الأساسية الكاملة وحزمة الطلب المسبق الرقمية القياسية لمدينة فايس سيتي.' : 'Full base game and standard Vice City pre-order digital pack.' },
                        { id: 'deluxe', label: t('header.deluxe'), price: '$89.99', desc: locale === 'ar' ? 'اللعبة الأساسية، مظاهر أسلحة فايس سيتي، ووصول مبكر لمدة 3 أيام لطور القصة.' : 'Base game, Vice City weapon skins, and 3-day early story mode access.' },
                        { id: 'collector', label: t('header.collector'), price: '$149.99', desc: locale === 'ar' ? 'الحزمة الفاخرة، الموسيقى التصويرية الرقمية المميزة، وتذكرة كتاب الصلب المادي التفاعلي.' : 'Deluxe bundle, premium digital soundtrack, and dynamic steelbook physical ticket.' }
                      ].map(edit => (
                        <button
                          key={edit.id}
                          onClick={() => setPreorderEdition(edit.id as any)}
                          className={`w-full p-3.5 text-left border transition-all flex justify-between items-start gap-4 ${
                            preorderEdition === edit.id
                              ? 'border-pink-500 bg-pink-500/10 text-white'
                              : 'border-white/5 bg-black text-zinc-400 hover:text-white'
                          }`}
                        >
                          <div className="space-y-1">
                            <span className="text-xs font-mono font-black uppercase block">{edit.label}</span>
                            <span className="text-[10px] text-zinc-500 font-sans block leading-snug">{edit.desc}</span>
                          </div>
                          <span className="font-mono text-xs font-bold text-pink-500 shrink-0">{edit.price}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Action Button */}
                  <button
                    onClick={() => setPreorderSuccess(true)}
                    className="w-full bg-gradient-to-r from-pink-500 to-orange-400 text-black font-display font-black text-xs uppercase tracking-widest py-4 hover:opacity-90 transition-opacity cursor-pointer"
                    id="preorder-submit-btn"
                  >
                    {t('header.register_btn')}
                  </button>
                </div>
              ) : (
                <div className="space-y-6 text-center py-4">
                  <div className="w-12 h-12 bg-pink-500 text-black mx-auto flex items-center justify-center font-display font-black text-xl">
                    ✓
                  </div>
                  <div className="space-y-2">
                    <span className="text-pink-500 font-mono text-[9px] tracking-widest uppercase font-black block">
                      {t('header.success_preorder')}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-display font-black text-white uppercase tracking-tight">
                      {t('header.success_preorder')}
                    </h3>
                    <p className="text-zinc-400 text-xs font-sans max-w-sm mx-auto">
                      {locale === 'ar' ? (
                        <>تم تسجيل تفضيلاتك للنسخة <strong className="text-white">{preorderEdition.toUpperCase()}</strong> على منصة <strong className="text-white">{preorderPlatform.toUpperCase()}</strong>. سيتم تنبيهك فور بدء الطلبات المسبقة رسمياً.</>
                      ) : (
                        <>Your preferences for the <strong className="text-white">{preorderEdition.toUpperCase()} EDITION</strong> on <strong className="text-white">{preorderPlatform.toUpperCase()}</strong> have been registered. You will be notified the instant official pre-orders open.</>
                      )}
                    </p>
                  </div>

                  {/* Mock Ticket */}
                  <div className="border border-dashed border-white/20 p-4 bg-zinc-900 font-mono text-left rtl:text-right space-y-3 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-1.5 bg-gradient-to-r from-pink-500 to-orange-400 left-0" />
                    <div className="flex justify-between text-[10px] text-zinc-500">
                      <span>ALERT_TYPE: LAUNCH_NOTIFICATION</span>
                      <span>SEC_KEY: #VI-{Math.floor(100000 + Math.random() * 900000)}</span>
                    </div>
                    <div className="border-t border-white/5 pt-2 flex justify-between items-center">
                      <div>
                        <span className="text-[9px] text-zinc-500 block">DESTINATION</span>
                        <span className="text-white text-xs font-bold font-display tracking-wide">{locale === 'ar' ? 'ولاية ليونيدا' : 'STATE OF LEONIDA'}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-zinc-500 block">OFFICIAL TARGET</span>
                        <span className="text-pink-400 text-xs font-bold">{locale === 'ar' ? 'خريف 2025' : 'FALL 2025'}</span>
                      </div>
                    </div>
                    <div className="border-t border-dashed border-white/10 pt-2.5 text-center">
                      <span className="text-[8px] text-zinc-600 block tracking-widest select-none">
                        ||| ||| | ||| |||| | ||| | ||||| | |||
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => setIsPreorderOpen(false)}
                    className="w-full bg-zinc-900 hover:bg-zinc-800 border border-white/10 text-white font-mono text-xs uppercase tracking-wider py-3 cursor-pointer"
                    id="preorder-finish-btn"
                  >
                    {t('header.close')}
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </header>
  );
}
