import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Brain, Cpu, ShieldCheck, Activity, AlertTriangle, CheckCircle, 
  Send, Sliders, Database, Network, Clock, Play, FileText, CheckCircle2,
  RefreshCw, Globe, HelpCircle, Check, ChevronRight, BarChart3, Radio, ArrowRight
} from 'lucide-react';

interface CustomClaimResult {
  id: string;
  claim: string;
  aiSummary: string;
  aiAnalysis: string;
  aiTrustReason: string;
  comparedSources: string[];
  timeline: { date: string; score: number; event: string }[];
  confidence: 'absolute' | 'high' | 'medium' | 'low';
  status: 'verified' | 'unconfirmed' | 'disputed' | 'refuted';
}

export default function AIDashboardView() {
  // Automated Publishing State
  const [isAutoPublishEnabled, setIsAutoPublishEnabled] = useState(true);
  const [minConfidence, setMinConfidence] = useState(85);
  const [crawlerTargets, setCrawlerTargets] = useState({
    newswire: true,
    reddit: true,
    twitter: false,
    gtaforums: true,
    investor: true
  });
  
  // Future Automatic Publishing Setup inputs
  const [discordWebhook, setDiscordWebhook] = useState('https://discord.com/api/webhooks/...');
  const [telegramToken, setTelegramToken] = useState('594029104:AAEqW38...');
  const [customEndpoint, setCustomEndpoint] = useState('https://api.gtavihub.com/v1/publish');
  const [sweepInterval, setSweepInterval] = useState('10m');
  const [handshakeStatus, setHandshakeStatus] = useState<'idle' | 'testing' | 'success' | 'failed'>('idle');
  const [handshakeLog, setHandshakeLog] = useState<string[]>([]);

  // Simulation State for Claim Ingestion
  const [scannedClaimsCount, setScannedClaimsCount] = useState(1494);
  const [publishedAlerts, setPublishedAlerts] = useState(324);
  const [reviewCount, setReviewCount] = useState(12);
  const [isScraperRunning, setIsScraperRunning] = useState(false);
  const [scraperLog, setScraperLog] = useState<string[]>([]);

  // Sandbox Claim Parser state
  const [sandboxClaimText, setSandboxClaimText] = useState('Pre-order promotional leaks suggest Rockstar is launching a digital-only tier in October with 4-day early access.');
  const [sandboxProgress, setSandboxProgress] = useState(0);
  const [sandboxStep, setSandboxStep] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [sandboxResult, setSandboxResult] = useState<CustomClaimResult | null>(null);

  // Seed standard preset templates
  const presets = [
    {
      title: "Audio Soundscape Leak",
      text: "Trailer 2 soundtrack uses a dynamic vapor-wave artist from Miami, confirmed via local music licensing registries."
    },
    {
      title: "Map Coordinate Speculation",
      text: "Leaked coordinator assets show the western bay extending past Leonida boundaries into state wetlands."
    },
    {
      title: "Physical Retail Shipment",
      text: "Retail stores in Florida claim marketing materials will arrive in October 2026 showing early November release sticker."
    }
  ];

  // Dynamic system updates simulation
  useEffect(() => {
    const interval = setInterval(() => {
      if (Math.random() > 0.5) {
        setScannedClaimsCount(prev => prev + 1);
        if (Math.random() > 0.8) {
          setPublishedAlerts(prev => prev + 1);
        }
      }
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleTestHandshake = () => {
    setHandshakeStatus('testing');
    setHandshakeLog([]);
    
    const logs = [
      "SYSTEM: Initializing handshake request to: " + customEndpoint,
      "SSL: Validating secure connection keys...",
      "AUTH: Handshake token verified securely. Payload: [CLIENT_ID: 3d8ea571]",
      "WEBHOOK: Discord connection response: 200 OK (Secure handshake successful)",
      "SYSTEM: Endpoint handshake completed successfully. Auto-publishing pipeline is green."
    ];

    let currentLogIdx = 0;
    const logInterval = setInterval(() => {
      if (currentLogIdx < logs.length) {
        setHandshakeLog(prev => [...prev, logs[currentLogIdx]]);
        currentLogIdx++;
      } else {
        clearInterval(logInterval);
        setHandshakeStatus('success');
      }
    }, 600);
  };

  const handleRunScraper = () => {
    setIsScraperRunning(true);
    setScraperLog([]);
    const logs = [
      "CRAWLER: Launching cloud nodes...",
      "CRAWLER: Querying Rockstar Newswire staging subdomains...",
      "CRAWLER: Fetching r/GTA6 speculative hot posts...",
      "NLP: Tokenizing 12 newly acquired textual records...",
      "CORE: Matching token hashes against Take-Two legal directory...",
      "COMPLETED: Ingestion loop verified. 0 high confidence anomalies found."
    ];

    let idx = 0;
    const runInt = setInterval(() => {
      if (idx < logs.length) {
        setScraperLog(prev => [...prev, logs[idx]]);
        idx++;
      } else {
        clearInterval(runInt);
        setIsScraperRunning(false);
        setScannedClaimsCount(prev => prev + 12);
      }
    }, 500);
  };

  const handleRunSandboxScan = () => {
    if (!sandboxClaimText.trim()) return;
    setIsScanning(true);
    setSandboxResult(null);
    setSandboxProgress(0);

    const steps = [
      { progress: 15, msg: "Initializing Natural Language Processing (NLP) Parser..." },
      { progress: 40, msg: "Checking Take-Two Intellectual Property patents & trademark logs..." },
      { progress: 65, msg: "Cross-referencing claims timeline against historical GTA timelines..." },
      { progress: 90, msg: "Computing forensic confidence levels & consensus rating weights..." },
      { progress: 100, msg: "Compiling 7-Field Intelligence Dossier..." }
    ];

    let stepIdx = 0;
    const progressInt = setInterval(() => {
      if (stepIdx < steps.length) {
        setSandboxProgress(steps[stepIdx].progress);
        setSandboxStep(steps[stepIdx].msg);
        stepIdx++;
      } else {
        clearInterval(progressInt);
        setIsScanning(false);

        // Generate dynamic result based on input text length/contents
        const textLower = sandboxClaimText.toLowerCase();
        let score = Math.floor(Math.random() * 40) + 45; // default medium range
        
        if (textLower.includes('official') || textLower.includes('rockstar')) {
          score = Math.floor(Math.random() * 20) + 75;
        } else if (textLower.includes(' Cousin') || textLower.includes('fake') || textLower.includes('retail')) {
          score = Math.floor(Math.random() * 30) + 15;
        }

        let confidence: 'absolute' | 'high' | 'medium' | 'low' = 'medium';
        if (score > 85) confidence = 'absolute';
        else if (score > 70) confidence = 'high';
        else if (score > 40) confidence = 'medium';
        else confidence = 'low';

        let status: 'verified' | 'unconfirmed' | 'disputed' | 'refuted' = 'unconfirmed';
        if (score > 85) status = 'verified';
        else if (score > 60) status = 'unconfirmed';
        else if (score > 35) status = 'disputed';
        else status = 'refuted';

        setSandboxResult({
          id: `SANDBOX-${Math.floor(Math.random() * 9000) + 1000}`,
          claim: sandboxClaimText,
          aiSummary: `AI evaluation of claim: "${sandboxClaimText.substring(0, 50)}..." indicates a ${status.toUpperCase()} asset credibility rating.`,
          aiAnalysis: `Our neural analysis indicates a structural consistency match index of ${score}%. The language formatting patterns represent standard consumer speculation with normal distribution of keyword phrases. Forensic check suggests no active Take-Two domain metadata associated with this claim profile.`,
          aiTrustReason: `Confidence score calculated based on source reputation history, physical coordinate plausibility, and Take-Two marketing pattern comparisons.`,
          comparedSources: ["Reddit Speculation Hub", "Rockstar Games CDN Staging", "Take-Two Investor Disclosures"],
          timeline: [
            { date: "Current Date", score: score, event: "Claim submitted to Sandbox Parser for neural evaluation" },
            { date: "24h ago", score: Math.max(10, score - 5), event: "Initial claim detected across minor forums" }
          ],
          confidence,
          status
        });
      }
    }, 800);
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'verified': return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'unconfirmed': return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
      case 'disputed': return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
      case 'refuted': return 'bg-red-500/15 text-red-400 border-red-500/30';
      default: return 'bg-zinc-800 text-zinc-400 border-zinc-700';
    }
  };

  const getConfidenceBadgeColor = (conf: string) => {
    switch (conf) {
      case 'absolute': return 'bg-pink-500/20 text-pink-400 border-pink-500/40';
      case 'high': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'medium': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'low': return 'bg-red-500/10 text-red-400 border-red-500/20';
      default: return 'bg-zinc-800 text-zinc-400 border-zinc-700';
    }
  };

  return (
    <div className="space-y-8 pb-12 max-w-7xl mx-auto" id="ai-news-dashboard-view">
      
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-white/5 pb-6">
        <div className="text-left">
          <div className="flex items-center space-x-2 text-pink-500 font-mono text-[10px] tracking-widest uppercase font-black mb-1">
            <Brain className="h-4 w-4 animate-pulse text-pink-500" />
            <span>AI NEWS INTELLIGENCE & AUTO-PUBLISHING</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-display font-black text-white tracking-tighter uppercase leading-none">
            AI News Dashboard
          </h1>
          <p className="text-zinc-400 text-sm mt-2 max-w-3xl font-sans">
            Real-time verification metrics, active crawling operations, and visual confidence density analyzers. Fine-tune automated publish thresholds and calibrate webhook queues.
          </p>
        </div>

        {/* Live Network Health Block */}
        <div className="bg-[#09090b]/90 border border-white/10 px-4 py-2.5 flex items-center gap-3 shrink-0">
          <div className="relative">
            <span className="flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-pink-500"></span>
            </span>
          </div>
          <div className="text-left font-mono">
            <span className="text-[9px] text-zinc-500 block uppercase font-bold">PIPELINE AUTONOMY</span>
            <span className="text-xs text-emerald-400 font-black uppercase">Active & Armed</span>
          </div>
        </div>
      </div>

      {/* Stats Overview Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4" id="dashboard-stats-grid">
        {[
          { title: "Claims Scanned", value: scannedClaimsCount.toLocaleString(), desc: "Crawlers actively processing", icon: Database, color: "text-pink-500" },
          { title: "Auto-Published", value: `${publishedAlerts} Alerts`, desc: "Pushed to client feeds", icon: CheckCircle2, color: "text-emerald-400" },
          { title: "Average Confidence", value: "87.4%", desc: "Accurate rating weight", icon: Activity, color: "text-cyan-400" },
          { title: "Review Backlog", value: `${reviewCount} cases`, desc: "Pending manual override", icon: AlertTriangle, color: "text-amber-500" }
        ].map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div key={idx} className="bg-black/40 border border-white/10 p-5 space-y-2 relative overflow-hidden text-left hover:border-pink-500/20 transition-all">
              <div className="absolute top-0 right-0 p-3 opacity-10">
                <Icon className="h-10 w-10 text-white" />
              </div>
              <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest block font-bold">{stat.title}</span>
              <h2 className="text-2xl sm:text-3xl font-display font-black text-white">{stat.value}</h2>
              <p className="text-[10px] text-zinc-400 font-mono leading-tight">{stat.desc}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT STAGE: Automated Publishing Config & Webhooks (7 Columns) */}
        <div className="lg:col-span-7 bg-[#09090b]/80 border border-white/10 p-6 space-y-6 text-left" id="publishing-config-panel">
          <div className="flex justify-between items-center border-b border-white/5 pb-3">
            <h3 className="font-display font-black text-sm uppercase tracking-wider text-white flex items-center gap-2">
              <Sliders className="h-5 w-5 text-pink-500" />
              <span>Prepared Automatic Publishing Pipeline</span>
            </h3>
            <span className="text-[9px] font-mono px-2 py-0.5 border border-pink-500/20 text-pink-400 uppercase bg-pink-500/5 font-black">
              INTEGRATION STAGED
            </span>
          </div>

          <p className="text-zinc-400 text-xs leading-relaxed font-sans">
            Calibrate the parameters for automatic post broadcasting. Once a scraped leak or official event exceeds the selected minimum confidence threshold, it will publish directly to client notification rails and external API handlers.
          </p>

          <div className="space-y-4 font-mono text-xs border-y border-white/5 py-4">
            {/* Auto Publish Toggle */}
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <span className="text-white font-black uppercase">Enable Auto-Publish Engine</span>
                <p className="text-[10px] text-zinc-500">Enable absolute automated feed injection</p>
              </div>
              <button 
                onClick={() => setIsAutoPublishEnabled(!isAutoPublishEnabled)}
                className={`w-12 h-6 flex items-center px-1 transition-colors rounded-none ${isAutoPublishEnabled ? 'bg-pink-600' : 'bg-zinc-800'}`}
              >
                <div className={`w-4 h-4 bg-black transition-transform ${isAutoPublishEnabled ? 'translate-x-6' : 'translate-x-0'}`} />
              </button>
            </div>

            {/* Slider: Min Confidence */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-white font-black uppercase">Auto-Publish Threshold</span>
                <span className="text-pink-500 font-black">{minConfidence}% Confidence</span>
              </div>
              <input 
                type="range" 
                min="60" 
                max="95" 
                value={minConfidence} 
                onChange={(e) => setMinConfidence(Number(e.target.value))}
                className="w-full accent-pink-500 h-1 bg-zinc-950 border border-white/5"
              />
              <div className="flex justify-between text-[9px] text-zinc-600">
                <span>60% (High Volatility)</span>
                <span>80% (Recommended)</span>
                <span>95% (Safe)</span>
              </div>
            </div>

            {/* Ingestion Targets */}
            <div className="space-y-2">
              <span className="text-white font-black uppercase block">Active Crawler Source Channels</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { key: 'newswire', label: 'Rockstar Newswire' },
                  { key: 'reddit', label: 'Reddit r/GTA6' },
                  { key: 'twitter', label: 'X (Twitter) Feed' },
                  { key: 'gtaforums', label: 'GTAForums' },
                  { key: 'investor', label: 'Take-Two SEC Records' }
                ].map((tgt) => (
                  <button
                    key={tgt.key}
                    onClick={() => setCrawlerTargets(prev => ({ ...prev, [tgt.key]: !prev[tgt.key as keyof typeof crawlerTargets] }))}
                    className={`flex items-center justify-between p-2 border text-[10px] uppercase font-bold text-left ${
                      crawlerTargets[tgt.key as keyof typeof crawlerTargets]
                        ? 'border-pink-500/30 bg-pink-500/5 text-pink-400'
                        : 'border-white/5 bg-black/40 text-zinc-500'
                    }`}
                  >
                    <span>{tgt.label}</span>
                    <span className="text-[8px] font-mono">{crawlerTargets[tgt.key as keyof typeof crawlerTargets] ? '● ON' : '○ OFF'}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Webhook & API Integrations (Prepared for Future Publishing) */}
          <div className="space-y-4">
            <span className="text-xs font-mono font-bold uppercase text-zinc-400 block">External Webhooks & API Sockets</span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-mono text-zinc-500 uppercase block">Discord Webhook Integration</label>
                <input 
                  type="text" 
                  value={discordWebhook}
                  onChange={(e) => setDiscordWebhook(e.target.value)}
                  className="w-full bg-black border border-white/10 px-3 py-2 text-zinc-300 font-mono text-xs focus:outline-none focus:border-pink-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-mono text-zinc-500 uppercase block">Telegram API Token</label>
                <input 
                  type="text" 
                  value={telegramToken}
                  onChange={(e) => setTelegramToken(e.target.value)}
                  className="w-full bg-black border border-white/10 px-3 py-2 text-zinc-300 font-mono text-xs focus:outline-none focus:border-pink-500"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-mono text-zinc-500 uppercase block">Custom POST Endpoint Socket</label>
              <div className="flex gap-2">
                <input 
                  type="text" 
                  value={customEndpoint}
                  onChange={(e) => setCustomEndpoint(e.target.value)}
                  className="flex-1 bg-black border border-white/10 px-3 py-2 text-zinc-300 font-mono text-xs focus:outline-none focus:border-pink-500"
                />
                
                <select
                  value={sweepInterval}
                  onChange={(e) => setSweepInterval(e.target.value)}
                  className="bg-black border border-white/10 px-2.5 py-1 text-zinc-400 text-xs font-mono focus:outline-none"
                >
                  <option value="1m">1m Sweep</option>
                  <option value="10m">10m Sweep</option>
                  <option value="1h">1h Sweep</option>
                  <option value="24h">Daily Sweep</option>
                </select>
              </div>
            </div>

            {/* Test Handshake Button */}
            <div className="bg-black border border-white/5 p-3.5 space-y-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center space-x-1.5 font-mono text-xs">
                  <Activity className="h-4 w-4 text-cyan-400" />
                  <span className="text-zinc-300 uppercase font-bold">API Socket Validation</span>
                </div>
                <button
                  onClick={handleTestHandshake}
                  disabled={handshakeStatus === 'testing'}
                  className="px-3 py-1.5 bg-pink-600 hover:bg-pink-500 text-black font-mono text-[10px] uppercase font-bold transition-colors select-none"
                >
                  {handshakeStatus === 'testing' ? 'Handshaking...' : 'Test Handshake'}
                </button>
              </div>

              {/* Handshake simulated log output */}
              {handshakeLog.length > 0 && (
                <div className="bg-[#030303] border border-white/5 p-2 font-mono text-[9px] text-zinc-500 space-y-1 h-24 overflow-y-auto">
                  {handshakeLog.map((log, lIdx) => (
                    <div key={lIdx} className={log.includes("successful") ? "text-emerald-400" : ""}>
                      {log}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* RIGHT STAGE: Spectrum Density Visualizer & Live Scraper Actions (5 Columns) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Spectrum Density Chart */}
          <div className="bg-black/60 border border-white/10 p-6 text-left space-y-5" id="spectrum-density-card">
            <h3 className="font-display font-black text-sm uppercase tracking-wider text-white border-b border-white/5 pb-3 flex items-center gap-2">
              <BarChart3 className="h-4.5 w-4.5 text-pink-500" />
              <span>Spectrum Density Distribution</span>
            </h3>

            <div className="space-y-3 font-mono text-xs">
              {[
                { label: "🟢 Official Releases", percent: "18%", color: "bg-emerald-500", raw: 268 },
                { label: "🔵 Trusted Journalism", percent: "28%", color: "bg-sky-500", raw: 418 },
                { label: "🟡 Highly Likely Leaks", percent: "31%", color: "bg-amber-500", raw: 463 },
                { label: "🟠 Unverified Rumors", percent: "15%", color: "bg-orange-500", raw: 224 },
                { label: "🔴 Debunked / Fabricated", percent: "8%", color: "bg-red-500", raw: 121 }
              ].map((spec, idx) => (
                <div key={idx} className="space-y-1.5">
                  <div className="flex justify-between text-[10px] font-bold text-zinc-400 uppercase">
                    <span>{spec.label}</span>
                    <span className="text-white">{spec.percent} ({spec.raw})</span>
                  </div>
                  <div className="w-full h-1.5 bg-zinc-950 p-0.5 border border-white/5">
                    <div className={`h-full ${spec.color}`} style={{ width: spec.percent }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Background Scraper triggers */}
          <div className="bg-black/40 border border-white/10 p-6 text-left space-y-4" id="scraper-trigger-card">
            <div className="flex justify-between items-center border-b border-white/5 pb-3">
              <h3 className="font-display font-black text-sm uppercase tracking-wider text-white flex items-center gap-2">
                <Radio className="h-4.5 w-4.5 text-pink-500" />
                <span>Live Ingestion Actions</span>
              </h3>
              <button
                onClick={handleRunScraper}
                disabled={isScraperRunning}
                className="px-3 py-1 bg-pink-500/10 border border-pink-500/30 hover:border-pink-500 text-pink-400 font-mono text-[9px] uppercase font-bold tracking-wider transition-colors"
              >
                {isScraperRunning ? 'Crawling...' : 'Force Crawl'}
              </button>
            </div>

            <p className="text-zinc-400 text-xs leading-relaxed font-sans">
              Force an instant sweep of active crawlers across digital game registries, forums, and X.
            </p>

            {scraperLog.length > 0 && (
              <div className="bg-zinc-950/80 border border-white/5 p-3 font-mono text-[9px] text-zinc-500 space-y-1 h-32 overflow-y-auto">
                {scraperLog.map((log, lIdx) => (
                  <div key={lIdx} className="leading-snug">
                    {log}
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

      {/* INTERACTIVE COMPONENT: Claim Forensic Analyzer Playground */}
      <div className="bg-black/60 border border-white/10 p-6 text-left space-y-6" id="claim-analyzer-sandbox">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-4">
          <div className="space-y-0.5">
            <h3 className="font-display font-black text-lg uppercase tracking-tight text-white flex items-center gap-2">
              <Brain className="h-5 w-5 text-pink-500" />
              <span>Claim Forensic Analyzer Sandbox</span>
            </h3>
            <p className="text-zinc-500 text-xs">Type speculation or paste leaked assets info to generate the updated 7-Field intelligence dossier.</p>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {presets.map((preset, idx) => (
              <button
                key={idx}
                onClick={() => setSandboxClaimText(preset.text)}
                className="px-2 py-1 bg-white/5 border border-white/10 text-zinc-400 hover:text-white hover:bg-white/10 font-mono text-[9px] uppercase transition-colors"
              >
                Template {idx + 1}: {preset.title}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Sandbox input block (5 columns) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="space-y-1">
              <label className="text-[10px] font-mono text-zinc-500 uppercase font-black block">Raw Claim Text</label>
              <textarea
                value={sandboxClaimText}
                onChange={(e) => setSandboxClaimText(e.target.value)}
                rows={4}
                placeholder="Type here..."
                className="w-full bg-[#030303] border border-white/10 p-3 text-zinc-300 font-sans text-xs focus:outline-none focus:border-pink-500 resize-none rounded-none"
              />
            </div>

            <button
              onClick={handleRunSandboxScan}
              disabled={isScanning || !sandboxClaimText.trim()}
              className="w-full py-3 bg-pink-600 hover:bg-pink-500 disabled:bg-zinc-800 disabled:text-zinc-600 text-black font-display font-black text-xs uppercase tracking-widest transition-colors flex items-center justify-center space-x-2"
            >
              <span>{isScanning ? 'SCANNING CORE NODE...' : 'RUN FORENSIC SCAN'}</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            {/* In-progress bar */}
            {isScanning && (
              <div className="space-y-2 font-mono text-xs bg-zinc-950 border border-white/5 p-3">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-zinc-400 font-black animate-pulse">{sandboxStep}</span>
                  <span className="text-pink-500 font-black">{sandboxProgress}%</span>
                </div>
                <div className="w-full h-1 bg-zinc-900 overflow-hidden">
                  <div className="h-full bg-pink-500 transition-all duration-300" style={{ width: `${sandboxProgress}%` }} />
                </div>
              </div>
            )}
          </div>

          {/* Result block (7 columns) showing all 7 fields! */}
          <div className="lg:col-span-7 bg-[#030303] border border-white/5 p-5 relative min-h-[300px] flex flex-col justify-center">
            {sandboxResult ? (
              <div className="space-y-5">
                
                {/* Result header */}
                <div className="flex justify-between items-start border-b border-white/5 pb-3">
                  <div className="space-y-0.5">
                    <span className="text-[9px] font-mono text-zinc-500 uppercase">SANDBOX RESULTS • {sandboxResult.id}</span>
                    <h4 className="text-white text-sm font-display font-black uppercase tracking-wider">Unified Forensic Intelligence Docket</h4>
                  </div>
                  
                  {/* Confidence & Status at top right */}
                  <div className="flex flex-col items-end gap-1 shrink-0">
                    <span className={`px-2 py-0.5 border text-[9px] font-mono uppercase font-black tracking-wider ${getStatusBadgeColor(sandboxResult.status)}`}>
                      AI STATUS: {sandboxResult.status}
                    </span>
                    <span className={`px-2 py-0.5 border text-[9px] font-mono uppercase font-black tracking-wider ${getConfidenceBadgeColor(sandboxResult.confidence)}`}>
                      AI CONFIDENCE: {sandboxResult.confidence}
                    </span>
                  </div>
                </div>

                {/* THE SEVEN MANDATED FIELDS IN SANDBOX PLAYGROUND */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                  
                  {/* 1. AI Summary */}
                  <div className="space-y-1.5 md:col-span-2">
                    <span className="text-[9px] text-pink-500 font-black uppercase tracking-widest block">1. AI Summary</span>
                    <div className="bg-pink-950/20 border border-pink-500/10 p-3 text-zinc-300 leading-relaxed font-sans">
                      {sandboxResult.aiSummary}
                    </div>
                  </div>

                  {/* 2. AI Analysis */}
                  <div className="space-y-1.5 md:col-span-2">
                    <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest block">2. AI Analysis</span>
                    <p className="bg-black/40 border border-white/5 p-3 text-zinc-300 leading-relaxed font-sans">
                      {sandboxResult.aiAnalysis}
                    </p>
                  </div>

                  {/* 3. AI Trust Reason */}
                  <div className="space-y-1.5">
                    <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest block">3. AI Trust Reason</span>
                    <p className="bg-black/40 border border-white/5 p-3 text-zinc-300 leading-relaxed font-sans">
                      {sandboxResult.aiTrustReason}
                    </p>
                  </div>

                  {/* 4. AI Compared Sources */}
                  <div className="space-y-1.5">
                    <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest block">4. AI Compared Sources</span>
                    <div className="space-y-1.5">
                      {sandboxResult.comparedSources.map((src, sIdx) => (
                        <div key={sIdx} className="flex items-center justify-between bg-black/40 border border-white/5 px-2.5 py-1.5 text-[10px]">
                          <span className="text-zinc-400 uppercase font-medium">{src}</span>
                          <span className="text-[8px] text-emerald-400 font-bold">VETTED</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 5. AI Timeline */}
                  <div className="space-y-1.5">
                    <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest block">5. AI Timeline</span>
                    <div className="space-y-2">
                      {sandboxResult.timeline.map((item, tIdx) => (
                        <div key={tIdx} className="border-l border-pink-500/30 pl-2.5 space-y-0.5 text-left text-[10px]">
                          <div className="flex justify-between items-center text-[9px] font-bold text-zinc-500 uppercase">
                            <span>{item.date}</span>
                            <span className="text-pink-400">{item.score}% Score</span>
                          </div>
                          <p className="text-zinc-400 font-sans leading-tight">{item.event}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* 6 & 7. Confidence & Status summary */}
                  <div className="space-y-3">
                    <div className="space-y-1">
                      <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest block">6. AI Confidence Level</span>
                      <div className="flex items-center space-x-2">
                        <div className="h-2 w-2 rounded-full bg-pink-500" />
                        <span className="text-white uppercase font-black tracking-wider text-[11px]">{sandboxResult.confidence}</span>
                      </div>
                    </div>

                    <div className="space-y-1">
                      <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest block">7. AI Verification Status</span>
                      <div className="flex items-center space-x-2">
                        <div className="h-2 w-2 rounded-full bg-cyan-400" />
                        <span className="text-white uppercase font-black tracking-wider text-[11px]">{sandboxResult.status}</span>
                      </div>
                    </div>
                  </div>

                </div>

              </div>
            ) : (
              <div className="text-center p-8 space-y-3">
                <Brain className="h-10 w-10 text-zinc-700 mx-auto" />
                <h4 className="text-white text-xs uppercase tracking-wider font-bold">Waiting for input</h4>
                <p className="text-zinc-500 text-xs max-w-sm mx-auto leading-normal">Type or choose a preset template, then click "RUN FORENSIC SCAN" to generate a complete 7-Field intelligence report.</p>
              </div>
            )}
          </div>
        </div>
      </div>

    </div>
  );
}
