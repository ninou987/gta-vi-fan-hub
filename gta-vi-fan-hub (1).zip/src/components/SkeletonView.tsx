import React from 'react';

export default function SkeletonView() {
  return (
    <div className="w-full space-y-6 py-6 font-mono text-left animate-pulse" id="skeleton-loading-container">
      {/* Skeleton Header */}
      <div className="space-y-2 border-b border-white/5 pb-4">
        <div className="h-3 w-48 bg-pink-500/20" />
        <div className="h-10 w-2/3 bg-zinc-900" />
        <div className="h-4 w-1/2 bg-zinc-950" />
      </div>

      {/* Grid Pattern / Bento Grid skeleton */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Box 1 */}
        <div className="bg-zinc-950 border border-white/5 p-4 space-y-3 h-48 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="h-3 w-1/3 bg-zinc-800" />
            <div className="h-6 w-3/4 bg-zinc-900" />
          </div>
          <div className="h-2 w-full bg-zinc-900" />
        </div>

        {/* Box 2 */}
        <div className="bg-zinc-950 border border-white/5 p-4 space-y-3 h-48 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="h-3 w-1/4 bg-zinc-800" />
            <div className="h-6 w-1/2 bg-zinc-900" />
          </div>
          <div className="h-2 w-full bg-zinc-900" />
        </div>

        {/* Box 3 */}
        <div className="bg-zinc-950 border border-white/5 p-4 space-y-3 h-48 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="h-3 w-1/2 bg-zinc-800" />
            <div className="h-6 w-2/3 bg-zinc-900" />
          </div>
          <div className="h-2 w-full bg-zinc-900" />
        </div>

      </div>

      {/* Large visual board skeleton */}
      <div className="bg-[#09090b] border border-white/5 p-5 space-y-4">
        <div className="h-4 w-1/4 bg-zinc-800" />
        <div className="h-64 bg-zinc-950 w-full" />
        <div className="space-y-2">
          <div className="h-3 w-full bg-zinc-900" />
          <div className="h-3 w-5/6 bg-zinc-900" />
          <div className="h-3 w-2/3 bg-zinc-900" />
        </div>
      </div>
    </div>
  );
}
