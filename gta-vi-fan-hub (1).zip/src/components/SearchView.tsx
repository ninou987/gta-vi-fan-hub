import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Compass, 
  Users, 
  Database, 
  Newspaper, 
  Film, 
  ArrowRight, 
  CornerDownRight, 
  Volume2, 
  VolumeX, 
  HelpCircle, 
  X, 
  Clock, 
  Sparkles, 
  Tag, 
  Image as ImageIcon, 
  Flame, 
  ShieldAlert, 
  ShieldCheck, 
  BookOpen, 
  AlertTriangle, 
  CheckCircle2, 
  ChevronRight, 
  Cpu
} from 'lucide-react';
import { charactersData, mapPointsData, databaseItemsData, timelineEventsData, trailerFramesData } from '../data/gtaData';
import { faqList } from './FAQView';
import { videoFeeds } from './VideosView';
import { galleryItems } from './GalleryView';
import { leakRecords } from './LeaksView';
import { ViewType } from '../types';
import TrustBadge from './TrustBadge';

interface SearchViewProps {
  setView: (view: ViewType) => void;
  setSelectedCharacterId?: (id: any) => void;
  setSelectedDatabaseTab?: (tab: any) => void;
}

// Word-Highlight Utility Component
function Highlight({ text, query }: { text: string; query: string }) {
  if (!text) return null;
  if (!query || !query.trim()) return <>{text}</>;
  try {
    const escapedQuery = query.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
    const regex = new RegExp(`(${escapedQuery})`, 'gi');
    const parts = text.split(regex);
    return (
      <>
        {parts.map((part, i) => 
          regex.test(part) ? (
            <mark key={i} className="bg-pink-500/25 text-pink-400 font-semibold px-0.5 rounded-sm select-none">
              {part}
            </mark>
          ) : (
            part
          )
        )}
      </>
    );
  } catch (err) {
    return <>{text}</>;
  }
}

export default function SearchView({ setView, setSelectedCharacterId, setSelectedDatabaseTab }: SearchViewProps) {
  const [query, setQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [isScanning, setIsScanning] = useState(false);
  const [isMuted, setIsMuted] = useState(() => {
    try {
      return localStorage.getItem('gta_hub_search_mute') === 'true';
    } catch (e) {
      return false;
    }
  });

  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('gta_hub_recent_searches');
      return saved ? JSON.parse(saved) : ['Lucia', 'Pegassi', 'RAGE 9', 'Everglades'];
    } catch (e) {
      return ['Lucia', 'Pegassi', 'RAGE 9', 'Everglades'];
    }
  });

  // Sound generator
  const playScanBeep = (freq = 1400, duration = 0.05) => {
    if (isMuted) return;
    try {
      const audioCtx = typeof window !== 'undefined' ? (window.AudioContext || (window as any).webkitAudioContext) : null;
      if (audioCtx) {
        const ctx = new audioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(freq + 300, ctx.currentTime + duration);
        gain.gain.setValueAtTime(0.015, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + duration);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + duration);
      }
    } catch (e) {}
  };

  const handleMuteToggle = () => {
    const nextMute = !isMuted;
    setIsMuted(nextMute);
    try {
      localStorage.setItem('gta_hub_search_mute', String(nextMute));
    } catch (e) {}
    if (!nextMute) {
      setTimeout(() => playScanBeep(1200, 0.08), 50);
    }
  };

  const saveToRecent = (term: string) => {
    const cleanTerm = term.trim();
    if (!cleanTerm) return;
    setRecentSearches(prev => {
      const filtered = prev.filter(item => item.toLowerCase() !== cleanTerm.toLowerCase());
      const updated = [cleanTerm, ...filtered].slice(0, 8);
      try {
        localStorage.setItem('gta_hub_recent_searches', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  const deleteFromRecent = (term: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches(prev => {
      const updated = prev.filter(item => item !== term);
      try {
        localStorage.setItem('gta_hub_recent_searches', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
    playScanBeep(900, 0.04);
  };

  const clearRecent = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem('gta_hub_recent_searches');
    } catch (e) {}
    playScanBeep(700, 0.06);
  };

  const handlePillClick = (term: string) => {
    setQuery(term);
    playScanBeep(1500, 0.06);
  };

  // Simulated scan debounce
  useEffect(() => {
    if (!query.trim()) {
      setIsScanning(false);
      return;
    }
    setIsScanning(true);
    const timer = setTimeout(() => {
      setIsScanning(false);
      if (query.trim().length >= 2) {
        saveToRecent(query);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [query]);

  // Combined Multi-Database Search Matcher
  const resultsByGroup = useMemo(() => {
    if (!query.trim()) return {
      news: [],
      leaks: [],
      characters: [],
      vehicles: [],
      weapons: [],
      videos: [],
      gallery: [],
      faq: [],
      totalCount: 0
    };

    const q = query.toLowerCase();

    // 1. News Search
    const matchedNews = timelineEventsData.filter(e => 
      e.category !== 'leak' && (
        e.title.toLowerCase().includes(q) ||
        e.summary.toLowerCase().includes(q) ||
        e.details.toLowerCase().includes(q) ||
        (e.tags && e.tags.some(tag => tag.toLowerCase().includes(q))) ||
        (e.sources && e.sources.some(src => src.toLowerCase().includes(q)))
      )
    );

    // 2. Leaks Search (Combine timeline leaks + technical leak records)
    const matchedTimelineLeaks = timelineEventsData.filter(e => 
      e.category === 'leak' && (
        e.title.toLowerCase().includes(q) ||
        e.summary.toLowerCase().includes(q) ||
        e.details.toLowerCase().includes(q) ||
        (e.tags && e.tags.some(tag => tag.toLowerCase().includes(q)))
      )
    );
    const matchedLeakRecords = leakRecords.filter(r => 
      r.title.toLowerCase().includes(q) ||
      r.summary.toLowerCase().includes(q) ||
      r.details.toLowerCase().includes(q) ||
      r.category.toLowerCase().includes(q) ||
      r.technicalBits.some(bit => bit.toLowerCase().includes(q))
    );
    const matchedLeaks = [
      ...matchedTimelineLeaks.map(item => ({ ...item, isTimelineEvent: true, uniqueId: `tleak-${item.id}` })),
      ...matchedLeakRecords.map(item => ({ ...item, isTimelineEvent: false, uniqueId: `techleak-${item.id}` }))
    ];

    // 3. Characters Search
    const matchedCharacters = charactersData.filter(c => 
      c.name.toLowerCase().includes(q) ||
      c.role.toLowerCase().includes(q) ||
      c.tagline.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.bio.toLowerCase().includes(q) ||
      c.associates.some(a => a.toLowerCase().includes(q)) ||
      c.keyEquip.some(eq => eq.toLowerCase().includes(q)) ||
      c.voiceLines.some(vl => vl.toLowerCase().includes(q))
    );

    // 4. Vehicles Search
    const matchedVehicles = databaseItemsData.filter(item => 
      item.type === 'vehicle' && (
        item.name.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.realLifeInspiration.toLowerCase().includes(q)
      )
    );

    // 5. Weapons Search
    const matchedWeapons = databaseItemsData.filter(item => 
      item.type === 'weapon' && (
        item.name.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.realLifeInspiration.toLowerCase().includes(q)
      )
    );

    // 6. Videos Search
    const matchedVideos = videoFeeds.filter(v => 
      v.title.toLowerCase().includes(q) ||
      v.source.toLowerCase().includes(q) ||
      v.synopsis.toLowerCase().includes(q) ||
      v.insights.some(ins => ins.toLowerCase().includes(q))
    );

    // 7. Gallery Search (Combine Concept Gallery items + Trailer Breakdown frames)
    const matchedGalleryItems = galleryItems.filter(g => 
      g.title.toLowerCase().includes(q) ||
      g.description.toLowerCase().includes(q) ||
      g.spottedElement.toLowerCase().includes(q) ||
      g.category.toLowerCase().includes(q) ||
      g.specs.some(sp => sp.toLowerCase().includes(q))
    );
    const matchedTrailerFrames = trailerFramesData.filter(f => 
      f.title.toLowerCase().includes(q) ||
      f.description.toLowerCase().includes(q) ||
      f.easterEggs.some(egg => egg.toLowerCase().includes(q))
    );
    const matchedGallery = [
      ...matchedGalleryItems.map(item => ({ ...item, isFrame: false, uniqueId: `gal-${item.id}` })),
      ...matchedTrailerFrames.map(item => ({ ...item, isFrame: true, uniqueId: `frame-${item.id}` }))
    ];

    // 8. FAQ Search
    const matchedFAQ = faqList.filter(f => 
      f.question.toLowerCase().includes(q) ||
      f.answer.toLowerCase().includes(q) ||
      f.communityNote.toLowerCase().includes(q) ||
      f.category.toLowerCase().includes(q)
    );

    const totalCount = 
      matchedNews.length + 
      matchedLeaks.length + 
      matchedCharacters.length + 
      matchedVehicles.length + 
      matchedWeapons.length + 
      matchedVideos.length + 
      matchedGallery.length + 
      matchedFAQ.length;

    return {
      news: matchedNews,
      leaks: matchedLeaks,
      characters: matchedCharacters,
      vehicles: matchedVehicles,
      weapons: matchedWeapons,
      videos: matchedVideos,
      gallery: matchedGallery,
      faq: matchedFAQ,
      totalCount
    };
  }, [query]);

  const navigateToResult = (targetView: ViewType, subId?: string, extra?: string) => {
    playScanBeep(1600, 0.08);

    if (targetView === 'characters' && subId && setSelectedCharacterId) {
      setSelectedCharacterId(subId);
    } else if (targetView === 'database' && setSelectedDatabaseTab && extra) {
      setSelectedDatabaseTab(extra as any);
    }
    setView(targetView);
  };

  const suggestedPills = ['Lucia', 'Pegassi', 'RAGE 9', 'Everglades', 'Glock', 'September 2022', 'Release Date', 'Cheetah'];

  const filterTabs = [
    { id: 'all', label: 'All', count: resultsByGroup.totalCount, icon: Compass },
    { id: 'news', label: 'News', count: resultsByGroup.news.length, icon: Newspaper },
    { id: 'leaks', label: 'Leaks', count: resultsByGroup.leaks.length, icon: ShieldAlert },
    { id: 'characters', label: 'Characters', count: resultsByGroup.characters.length, icon: Users },
    { id: 'vehicles', label: 'Vehicles', count: resultsByGroup.vehicles.length, icon: Database },
    { id: 'weapons', label: 'Weapons', count: resultsByGroup.weapons.length, icon: Flame },
    { id: 'videos', label: 'Videos', count: resultsByGroup.videos.length, icon: Film },
    { id: 'gallery', label: 'Gallery', count: resultsByGroup.gallery.length, icon: ImageIcon },
    { id: 'faq', label: 'FAQ', count: resultsByGroup.faq.length, icon: HelpCircle },
  ];

  return (
    <div className="space-y-8 pb-12" id="search-view-root">
      
      {/* Title Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <span className="text-pink-500 font-mono text-[10px] tracking-widest uppercase font-black block mb-1">
            GLOBAL SURVEILLANCE DIRECTORY
          </span>
          <h1 className="text-3xl sm:text-5xl font-display font-black text-white tracking-tighter uppercase leading-none">
            Catalog Intelligence Search
          </h1>
          <p className="text-zinc-400 text-sm mt-2 max-w-2xl font-sans">
            Trace coordinate markers, systemic vehicle databases, leak filings, character bios, and media archives through a fast, integrated radar grid.
          </p>
        </div>

        {/* Sound Toggle */}
        <button
          onClick={handleMuteToggle}
          className={`flex items-center gap-2 px-3 py-1.5 border font-mono text-[10px] tracking-widest uppercase select-none transition-all duration-200 ${
            isMuted 
              ? 'bg-zinc-900/50 border-zinc-800 text-zinc-500 hover:text-zinc-400' 
              : 'bg-pink-950/20 border-pink-500/20 text-pink-400 hover:bg-pink-950/30'
          }`}
          title={isMuted ? 'Unmute scanner hums' : 'Mute scanner hums'}
        >
          {isMuted ? <VolumeX className="h-3.5 w-3.5 text-zinc-500" /> : <Volume2 className="h-3.5 w-3.5 text-pink-500 animate-pulse" />}
          <span>{isMuted ? 'Muted' : 'Audio Active'}</span>
        </button>
      </div>

      {/* Primary Search Container */}
      <div className="bg-black border border-white/10 p-6 md:p-8 space-y-4 rounded-none relative overflow-hidden">
        {/* Dynamic scanlines accent */}
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-pink-500/30 to-transparent animate-scanline" />

        <div className="relative">
          <Search className="absolute left-4 top-4.5 h-5 w-5 text-pink-500" />
          <input
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              if (e.target.value.length % 3 === 0) playScanBeep(1450, 0.04);
            }}
            placeholder="INPUT PARAMETERS (e.g., Lucia, Pegassi, RAGE 9, Everglades, Release)..."
            className="w-full bg-[#09090b] border border-white/10 p-4 pl-12 text-sm sm:text-base text-white font-mono placeholder-zinc-600 focus:outline-none focus:border-pink-500 focus:shadow-[0_0_15px_rgba(236,72,153,0.1)] transition-all rounded-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => {
                setQuery('');
                playScanBeep(1100, 0.06);
              }}
              className="absolute right-4 top-4.5 text-zinc-500 hover:text-white transition-colors"
              title="Clear input"
            >
              <X className="h-5 w-5" />
            </button>
          )}
        </div>

        {/* Hot Suggestions */}
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <span className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest flex items-center gap-1 shrink-0">
            <Sparkles className="h-3.5 w-3.5 text-pink-500" />
            Recommended Scans:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {suggestedPills.map((pill) => (
              <button
                key={pill}
                onClick={() => handlePillClick(pill)}
                className={`px-2.5 py-1 text-[10px] font-mono border transition-all rounded-none select-none ${
                  query.toLowerCase() === pill.toLowerCase()
                    ? 'bg-pink-500/10 border-pink-500 text-pink-400 font-bold'
                    : 'bg-white/5 border-white/5 text-zinc-400 hover:text-white hover:border-pink-500/30 hover:bg-pink-500/5'
                }`}
              >
                {pill}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Results Deck & Filters */}
      <div className="space-y-6">
        
        {/* Dynamic Category Navigation Deck */}
        {query.trim() && (
          <div className="border-b border-white/10 pb-1 overflow-x-auto scrollbar-thin">
            <div className="flex gap-1 min-w-max pb-2">
              {filterTabs.map((tab) => {
                const Icon = tab.icon;
                const isSelected = activeFilter === tab.id;
                // If count is 0, let's keep it styled subtly
                const isEmpty = tab.count === 0;

                return (
                  <button
                    key={tab.id}
                    onClick={() => {
                      setActiveFilter(tab.id);
                      playScanBeep(1500, 0.05);
                    }}
                    className={`flex items-center gap-2 px-3 py-2 font-mono text-[10px] tracking-widest uppercase border select-none transition-all duration-150 ${
                      isSelected
                        ? 'bg-pink-500/10 border-pink-500 text-pink-400 font-black'
                        : isEmpty
                          ? 'bg-transparent border-transparent text-zinc-600 hover:text-zinc-500 cursor-not-allowed'
                          : 'bg-zinc-950/40 border-white/5 text-zinc-400 hover:text-white hover:border-pink-500/20'
                    }`}
                    disabled={isEmpty && tab.id !== 'all'}
                  >
                    <Icon className={`h-3.5 w-3.5 ${isSelected ? 'text-pink-500' : 'text-zinc-500'}`} />
                    <span>{tab.label}</span>
                    <span className={`px-1.5 py-0.5 text-[9px] font-bold font-sans ${
                      isSelected 
                        ? 'bg-pink-500 text-black' 
                        : isEmpty 
                          ? 'bg-zinc-900 text-zinc-600' 
                          : 'bg-zinc-800 text-zinc-400'
                    }`}>
                      {tab.count}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Dynamic Rendering Flow */}
        <AnimatePresence mode="wait">
          {isScanning ? (
            /* Immersive Diagnostic Scan State */
            <motion.div
              key="scanning"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-4 text-left"
              id="search-scanning-skeletons"
            >
              <div className="text-[10px] font-mono text-pink-500 uppercase tracking-widest animate-pulse flex items-center gap-2">
                <span className="h-1.5 w-1.5 bg-pink-500 rounded-full animate-ping" />
                <span>[SCANNING_DECK] EXAMINING LEONIDA INTEGRATED REGISTRIES... INDEX ACTIVE</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="border border-white/5 bg-[#030303] p-5 space-y-4 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-full w-[2px] bg-pink-500/10 animate-pulse" />
                    <div className="flex items-center gap-2">
                      <div className="h-3 w-16 bg-zinc-800/80 animate-pulse" />
                      <div className="h-3 w-10 bg-zinc-800/80 animate-pulse" />
                    </div>
                    <div className="h-5 bg-zinc-800 w-2/3 animate-pulse" />
                    <div className="space-y-1.5 pt-2">
                      <div className="h-2.5 bg-zinc-900 w-full animate-pulse" />
                      <div className="h-2.5 bg-zinc-900 w-4/5 animate-pulse" />
                    </div>
                    <div className="h-3 bg-pink-500/10 w-24 animate-pulse mt-2" />
                  </div>
                ))}
              </div>
            </motion.div>
          ) : !query.trim() ? (
            /* Initial System Directory Portal */
            <motion.div
              key="initial"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-6"
            >
              {/* Left Column: Recent Searches & Instructions */}
              <div className="lg:col-span-2 bg-black/40 border border-white/5 p-6 space-y-6">
                <div>
                  <h3 className="text-xs font-mono text-zinc-400 uppercase tracking-widest flex items-center gap-1.5 font-bold border-b border-white/5 pb-2">
                    <Clock className="h-4 w-4 text-pink-500" />
                    Systemic Trace History
                  </h3>
                  
                  {recentSearches.length > 0 ? (
                    <div className="space-y-3 pt-3">
                      <div className="flex flex-wrap gap-2">
                        {recentSearches.map((term, idx) => (
                          <div
                            key={idx}
                            onClick={() => handlePillClick(term)}
                            className="group flex items-center bg-zinc-950 border border-white/5 text-zinc-400 hover:text-white hover:border-pink-500/30 px-3 py-1.5 text-xs font-mono cursor-pointer select-none transition-all"
                          >
                            <span>{term}</span>
                            <button
                              onClick={(e) => deleteFromRecent(term, e)}
                              className="ml-2 text-zinc-600 hover:text-pink-500 transition-colors p-0.5"
                              title={`Remove "${term}"`}
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                      <div className="pt-2 text-left">
                        <button
                          onClick={clearRecent}
                          className="text-[10px] font-mono text-zinc-500 hover:text-pink-400 uppercase tracking-widest transition-colors"
                        >
                          Clear Trace History
                        </button>
                      </div>
                    </div>
                  ) : (
                    <p className="text-zinc-600 font-mono text-xs pt-4">
                      No recent trace parameters stored in this sandbox.
                    </p>
                  )}
                </div>

                {/* Scan Tips */}
                <div className="space-y-3">
                  <h3 className="text-xs font-mono text-zinc-400 uppercase tracking-widest font-bold border-b border-white/5 pb-2">
                    Intel Search Operations
                  </h3>
                  <ul className="space-y-2 text-xs font-sans text-zinc-400 list-none pl-0">
                    <li className="flex items-start gap-2">
                      <span className="text-pink-500 font-mono font-black shrink-0">▶</span>
                      <span><strong>Unified Scanning:</strong> One input filters News, Patents, Characters, Concept Galleries, FAQs, and Video listings at once.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-pink-500 font-mono font-black shrink-0">▶</span>
                      <span><strong>Dynamic Filters:</strong> Click category tags to drill down into specific database indices.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-pink-500 font-mono font-black shrink-0">▶</span>
                      <span><strong>Highlighting Engine:</strong> Matching text ranges are illuminated automatically to highlight context.</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Right Column: Portal Directories */}
              <div className="bg-black/40 border border-white/5 p-6 space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center gap-1.5 text-[10px] font-mono text-zinc-400 uppercase tracking-widest font-bold">
                    <Cpu className="h-4 w-4 text-pink-500 animate-spin-slow" />
                    <span>Active Directory Portals</span>
                  </div>
                  <p className="text-xs text-zinc-500 leading-relaxed font-sans">
                    Quickly jump into primary database categories to browse without keyword parameters:
                  </p>
                  
                  <div className="space-y-2 pt-2 text-left">
                    {[
                      { label: 'Protagonists Dossiers', view: 'characters' as const },
                      { label: 'Weapons & Vehicles', view: 'database' as const },
                      { label: 'Radar Map Tracker', view: 'map' as const },
                      { label: 'Verification Center', view: 'news' as const },
                      { label: 'Official FAQ Deck', view: 'faq' as const },
                    ].map((portal, i) => (
                      <button
                        key={i}
                        onClick={() => navigateToResult(portal.view)}
                        className="w-full flex items-center justify-between p-2.5 bg-zinc-950 border border-white/5 text-xs text-zinc-300 font-mono uppercase tracking-wider hover:text-white hover:border-pink-500 hover:bg-pink-950/15 transition-all select-none"
                      >
                        <span>{portal.label}</span>
                        <ChevronRight className="h-4 w-4 text-pink-500" />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5 text-[10px] font-mono text-zinc-600">
                  SECURE RADAR PORT 3000 • LEONIDA GLOBAL
                </div>
              </div>
            </motion.div>
          ) : resultsByGroup.totalCount === 0 ? (
            /* Radar Scan Fail Empty State */
            <motion.div
              key="empty"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="text-center py-16 bg-zinc-950 border border-white/10 space-y-5"
            >
              <div className="relative inline-block">
                <div className="absolute inset-0 bg-pink-500/20 blur-xl rounded-full" />
                <ShieldAlert className="h-12 w-12 text-pink-500 relative mx-auto" />
              </div>
              <div className="space-y-2 max-w-md mx-auto">
                <h3 className="text-base font-mono text-white uppercase tracking-widest font-black">
                  RADAR SCAN RETURNED NO DATABASE MATCHES
                </h3>
                <p className="text-zinc-500 text-xs font-sans leading-relaxed">
                  No record was found matching "<span className="text-pink-400 font-mono font-bold">{query}</span>" in the Leonida systems. Ensure parameters match common names, brands, or categories.
                </p>
              </div>

              {/* Suggestions */}
              <div className="pt-4 space-y-2">
                <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">
                  Try Scanning These Parameters:
                </p>
                <div className="flex flex-wrap justify-center gap-1.5 max-w-lg mx-auto px-4">
                  {['Lucia', 'Jason', 'Glock', 'Cheetah', 'Everglades', 'September 2022', 'RAGE 9', 'Release Date'].map((term) => (
                    <button
                      key={term}
                      onClick={() => handlePillClick(term)}
                      className="px-3 py-1.5 text-xs font-mono bg-black border border-white/5 text-zinc-400 hover:text-white hover:border-pink-500 transition-all select-none rounded-none"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          ) : (
            /* Rendered Results categorized with Highlights */
            <motion.div
              key="results"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-10"
            >
              {/* Scanner Header Summary */}
              <div className="text-xs font-mono text-zinc-500 uppercase tracking-widest flex items-center justify-between border-b border-white/10 pb-2">
                <span>RADAR FEEDBACK DIAGNOSTICS</span>
                <span>MATCHING INTEL: <span className="text-pink-500 font-black">{resultsByGroup.totalCount} RECORDS</span></span>
              </div>

              {/* 1. Category News */}
              {(activeFilter === 'all' || activeFilter === 'news') && resultsByGroup.news.length > 0 && (
                <div className="space-y-4 text-left">
                  <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black border-b border-white/5 pb-2">
                    <Newspaper className="h-4 w-4 text-pink-500" />
                    <span>Verified News Reports ({resultsByGroup.news.length})</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {resultsByGroup.news.map(evt => (
                      <div 
                        key={evt.id} 
                        className="bg-black border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-pink-500/30 transition-all duration-200"
                      >
                        <div className="space-y-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[9px] font-mono text-zinc-500 uppercase bg-white/5 px-2 py-0.5 border border-white/5">
                              {evt.date}
                            </span>
                            {evt.trustBadge && <TrustBadge badge={evt.trustBadge} size="sm" />}
                          </div>
                          
                          <h3 className="text-base font-display font-black text-white uppercase tracking-tight">
                            <Highlight text={evt.title} query={query} />
                          </h3>
                          <p className="text-zinc-400 text-xs leading-relaxed line-clamp-2">
                            <Highlight text={evt.summary} query={query} />
                          </p>
                          <p className="text-zinc-500 text-[11px] leading-relaxed line-clamp-3 italic font-sans border-l-2 border-white/10 pl-3">
                            <Highlight text={evt.details} query={query} />
                          </p>

                          {/* Sources list */}
                          {evt.sources && evt.sources.length > 0 && (
                            <div className="pt-2 flex flex-wrap gap-1 items-center">
                              <span className="text-[9px] font-mono text-zinc-500 uppercase mr-1">Sources:</span>
                              {evt.sources.map((src, sidx) => (
                                <span key={sidx} className="bg-zinc-950 border border-white/5 px-1.5 py-0.5 text-[9px] font-mono text-zinc-400">
                                  <Highlight text={src} query={query} />
                                </span>
                              ))}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-white/5">
                          <span className="text-[9px] font-mono text-zinc-500">VIEWS: {evt.views || 0}</span>
                          <button
                            onClick={() => navigateToResult('news')}
                            className="text-[10px] font-mono text-pink-500 uppercase tracking-wider hover:text-white flex items-center gap-1 select-none"
                          >
                            <span>Inspect News Ledger</span>
                            <CornerDownRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 2. Category Leaks */}
              {(activeFilter === 'all' || activeFilter === 'leaks') && resultsByGroup.leaks.length > 0 && (
                <div className="space-y-4 text-left">
                  <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black border-b border-white/5 pb-2">
                    <ShieldAlert className="h-4 w-4 text-pink-500" />
                    <span>Intercepted Leaks & Patents ({resultsByGroup.leaks.length})</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {resultsByGroup.leaks.map(leak => (
                      <div 
                        key={leak.uniqueId} 
                        className="bg-black border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-pink-500/30 transition-all duration-200"
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[9px] font-mono text-zinc-500 uppercase bg-white/5 px-2 py-0.5 border border-white/5">
                              {leak.date}
                            </span>
                            {'impact' in leak && (
                              <span className={`px-2 py-0.5 text-[9px] font-mono uppercase tracking-wider border flex items-center gap-1 ${
                                leak.impact === 'Critical' 
                                  ? 'bg-red-500/10 border-red-500/20 text-red-400' 
                                  : leak.impact === 'High'
                                    ? 'bg-orange-500/10 border-orange-500/20 text-orange-400'
                                    : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
                              }`}>
                                <AlertTriangle className="h-3 w-3" />
                                <span>{leak.impact} Impact</span>
                              </span>
                            )}
                            {'trustBadge' in leak && (
                              <TrustBadge badge={leak.trustBadge} size="sm" />
                            )}
                          </div>
                          
                          <h3 className="text-base font-display font-black text-white uppercase tracking-tight">
                            <Highlight text={leak.title} query={query} />
                          </h3>
                          <p className="text-zinc-400 text-xs leading-relaxed line-clamp-2">
                            <Highlight text={leak.summary} query={query} />
                          </p>
                          <p className="text-zinc-500 text-[11px] leading-relaxed line-clamp-3 italic font-sans border-l-2 border-white/10 pl-3">
                            <Highlight text={leak.details} query={query} />
                          </p>

                          {/* Technical bits / tags */}
                          {'technicalBits' in leak && leak.technicalBits && (
                            <div className="pt-2 space-y-1">
                              <span className="text-[9px] font-mono text-zinc-500 uppercase block">Diagnostic Logs:</span>
                              <div className="flex flex-wrap gap-1">
                                {leak.technicalBits.map((bit, bidx) => (
                                  <span key={bidx} className="bg-zinc-950 border border-white/5 px-1.5 py-0.5 text-[9px] font-mono text-zinc-400">
                                    <Highlight text={bit} query={query} />
                                  </span>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center justify-end pt-2 border-t border-white/5">
                          <button
                            onClick={() => navigateToResult('leaks')}
                            className="text-[10px] font-mono text-pink-500 uppercase tracking-wider hover:text-white flex items-center gap-1 select-none"
                          >
                            <span>Access Leaks Terminal</span>
                            <CornerDownRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. Category Characters */}
              {(activeFilter === 'all' || activeFilter === 'characters') && resultsByGroup.characters.length > 0 && (
                <div className="space-y-4 text-left">
                  <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black border-b border-white/5 pb-2">
                    <Users className="h-4 w-4 text-pink-500" />
                    <span>Protagonist Intelligence Dossiers ({resultsByGroup.characters.length})</span>
                  </div>
                  
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {resultsByGroup.characters.map(c => (
                      <div 
                        key={c.id} 
                        className="bg-black border border-white/10 p-5 flex flex-col md:flex-row gap-5 hover:border-pink-500/30 transition-all duration-200"
                      >
                        {/* Portrait section */}
                        {c.imageUrl && (
                          <div className="w-full md:w-32 h-44 md:h-full relative overflow-hidden bg-zinc-900 border border-white/5 shrink-0">
                            <img 
                              src={c.imageUrl} 
                              alt={c.name} 
                              className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                            <div className="absolute bottom-2 left-2">
                              <span className="text-[9px] font-mono bg-pink-500 text-black px-1.5 py-0.5 uppercase font-black">
                                {c.id}
                              </span>
                            </div>
                          </div>
                        )}

                        <div className="flex-1 flex flex-col justify-between space-y-4">
                          <div className="space-y-2">
                            <div className="space-y-0.5">
                              <span className="text-[9px] font-mono text-zinc-500 uppercase block">ROLE: <Highlight text={c.role} query={query} /></span>
                              <h3 className="text-xl font-display font-black text-white uppercase tracking-tight">{c.name}</h3>
                              <p className="text-[10px] font-mono text-pink-400 italic">
                                "<Highlight text={c.tagline} query={query} />"
                              </p>
                            </div>

                            <p className="text-zinc-400 text-xs leading-relaxed line-clamp-3">
                              <Highlight text={c.description} query={query} />
                            </p>

                            {/* Equipment / associates */}
                            <div className="grid grid-cols-2 gap-2 pt-1">
                              <div>
                                <span className="text-[9px] font-mono text-zinc-500 uppercase block mb-1">Equipment:</span>
                                <div className="flex flex-wrap gap-1">
                                  {c.keyEquip.slice(0, 2).map((eq, eidx) => (
                                    <span key={eidx} className="bg-zinc-950 border border-white/5 px-1 py-0.5 text-[8px] font-mono text-zinc-400">
                                      <Highlight text={eq} query={query} />
                                    </span>
                                  ))}
                                </div>
                              </div>
                              <div>
                                <span className="text-[9px] font-mono text-zinc-500 uppercase block mb-1">Associates:</span>
                                <div className="flex flex-wrap gap-1">
                                  {c.associates.slice(0, 2).map((asc, asidx) => (
                                    <span key={asidx} className="bg-zinc-950 border border-white/5 px-1 py-0.5 text-[8px] font-mono text-zinc-400">
                                      <Highlight text={asc} query={query} />
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>

                          <div className="flex justify-end pt-2 border-t border-white/5">
                            <button
                              onClick={() => navigateToResult('characters', c.id)}
                              className="text-[10px] font-mono text-pink-500 uppercase tracking-wider hover:text-white flex items-center gap-1 select-none"
                            >
                              <span>Trace Profile</span>
                              <CornerDownRight className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 4. Category Vehicles */}
              {(activeFilter === 'all' || activeFilter === 'vehicles') && resultsByGroup.vehicles.length > 0 && (
                <div className="space-y-4 text-left">
                  <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black border-b border-white/5 pb-2">
                    <Database className="h-4 w-4 text-pink-500" />
                    <span>Confirmed & Speculated Vehicles ({resultsByGroup.vehicles.length})</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {resultsByGroup.vehicles.map(item => (
                      <div 
                        key={item.id} 
                        className="bg-black border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-pink-500/30 transition-all duration-200"
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[9px] font-mono text-zinc-500 uppercase bg-white/5 px-2 py-0.5 border border-white/5">
                              {item.category}
                            </span>
                            <span className={`px-2 py-0.5 text-[9px] font-mono uppercase font-black tracking-wider ${
                              item.status === 'Confirmed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                            }`}>
                              {item.status}
                            </span>
                          </div>
                          
                          <h3 className="text-base font-display font-black text-white uppercase tracking-tight">
                            <Highlight text={item.name} query={query} />
                          </h3>
                          
                          <p className="text-zinc-500 text-[10px] font-mono uppercase">
                            INSPIRED BY: <span className="text-zinc-300"><Highlight text={item.realLifeInspiration} query={query} /></span>
                          </p>

                          <p className="text-zinc-400 text-xs leading-relaxed">
                            <Highlight text={item.description} query={query} />
                          </p>

                          {/* Stats Bars */}
                          <div className="pt-2 space-y-1.5 border-t border-white/5">
                            <div className="flex items-center justify-between text-[9px] font-mono text-zinc-500">
                              <span>{item.specs.stat1Name.toUpperCase()}: {item.specs.stat1Value} / 100</span>
                            </div>
                            <div className="h-1.5 bg-zinc-950 border border-white/5 w-full">
                              <div className="h-full bg-pink-500" style={{ width: `${item.specs.stat1Value}%` }} />
                            </div>

                            <div className="flex items-center justify-between text-[9px] font-mono text-zinc-500">
                              <span>{item.specs.stat2Name.toUpperCase()}: {item.specs.stat2Value} / 100</span>
                            </div>
                            <div className="h-1.5 bg-zinc-950 border border-white/5 w-full">
                              <div className="h-full bg-pink-500" style={{ width: `${item.specs.stat2Value}%` }} />
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-white/5">
                          <span className="text-[9px] font-mono text-zinc-500">TRAILER SCENE: {item.trailerSceneTime}</span>
                          <button
                            onClick={() => navigateToResult('database', undefined, 'vehicle')}
                            className="text-[10px] font-mono text-pink-500 uppercase tracking-wider hover:text-white flex items-center gap-1 select-none"
                          >
                            <span>Inspect Vehicle Deck</span>
                            <CornerDownRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 5. Category Weapons */}
              {(activeFilter === 'all' || activeFilter === 'weapons') && resultsByGroup.weapons.length > 0 && (
                <div className="space-y-4 text-left">
                  <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black border-b border-white/5 pb-2">
                    <Flame className="h-4 w-4 text-pink-500" />
                    <span>Combat Arsenal & Armament ({resultsByGroup.weapons.length})</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {resultsByGroup.weapons.map(item => (
                      <div 
                        key={item.id} 
                        className="bg-black border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-pink-500/30 transition-all duration-200"
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[9px] font-mono text-zinc-500 uppercase bg-white/5 px-2 py-0.5 border border-white/5">
                              {item.category}
                            </span>
                            <span className={`px-2 py-0.5 text-[9px] font-mono uppercase font-black tracking-wider ${
                              item.status === 'Confirmed' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20'
                            }`}>
                              {item.status}
                            </span>
                          </div>
                          
                          <h3 className="text-base font-display font-black text-white uppercase tracking-tight">
                            <Highlight text={item.name} query={query} />
                          </h3>
                          
                          <p className="text-zinc-500 text-[10px] font-mono uppercase">
                            REAL ANALOG: <span className="text-zinc-300"><Highlight text={item.realLifeInspiration} query={query} /></span>
                          </p>

                          <p className="text-zinc-400 text-xs leading-relaxed">
                            <Highlight text={item.description} query={query} />
                          </p>

                          {/* Weapons Stats Bars */}
                          <div className="pt-2 space-y-1.5 border-t border-white/5">
                            <div className="flex items-center justify-between text-[9px] font-mono text-zinc-500">
                              <span>{item.specs.stat1Name.toUpperCase()}: {item.specs.stat1Value} / 100</span>
                            </div>
                            <div className="h-1.5 bg-zinc-950 border border-white/5 w-full">
                              <div className="h-full bg-orange-500" style={{ width: `${item.specs.stat1Value}%` }} />
                            </div>

                            <div className="flex items-center justify-between text-[9px] font-mono text-zinc-500">
                              <span>{item.specs.stat2Name.toUpperCase()}: {item.specs.stat2Value} / 100</span>
                            </div>
                            <div className="h-1.5 bg-zinc-950 border border-white/5 w-full">
                              <div className="h-full bg-orange-500" style={{ width: `${item.specs.stat2Value}%` }} />
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-white/5">
                          <span className="text-[9px] font-mono text-zinc-500">SCENE TRIGGER: {item.trailerSceneTime}</span>
                          <button
                            onClick={() => navigateToResult('database', undefined, 'weapon')}
                            className="text-[10px] font-mono text-pink-500 uppercase tracking-wider hover:text-white flex items-center gap-1 select-none"
                          >
                            <span>Inspect Arsenal Deck</span>
                            <CornerDownRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 6. Category Videos */}
              {(activeFilter === 'all' || activeFilter === 'videos') && resultsByGroup.videos.length > 0 && (
                <div className="space-y-4 text-left">
                  <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black border-b border-white/5 pb-2">
                    <Film className="h-4 w-4 text-pink-500" />
                    <span>Dynamic Video Feeds ({resultsByGroup.videos.length})</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {resultsByGroup.videos.map(video => (
                      <div 
                        key={video.id} 
                        className="bg-black border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-pink-500/30 transition-all duration-200"
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-[9px] font-mono text-zinc-500">
                            <span>{video.source}</span>
                            <span>{video.releaseDate}</span>
                          </div>

                          <h3 className="text-base font-display font-black text-white uppercase tracking-tight">
                            <Highlight text={video.title} query={query} />
                          </h3>

                          <p className="text-zinc-400 text-xs leading-relaxed">
                            <Highlight text={video.synopsis} query={query} />
                          </p>

                          {/* Insights bullets */}
                          {video.insights && video.insights.length > 0 && (
                            <div className="pt-2 space-y-1.5 border-t border-white/5">
                              <span className="text-[9px] font-mono text-pink-500 uppercase block font-black">Video Insights:</span>
                              <ul className="space-y-1 list-none pl-0">
                                {video.insights.slice(0, 2).map((ins, insIdx) => (
                                  <li key={insIdx} className="text-zinc-500 text-[11px] flex items-start gap-1">
                                    <span className="text-pink-500 font-mono text-[9px] mt-0.5">▶</span>
                                    <span><Highlight text={ins} query={query} /></span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>

                        <div className="flex items-center justify-between pt-2 border-t border-white/5">
                          <span className="text-[9px] font-mono text-zinc-500">DURATION: {video.duration}</span>
                          <button
                            onClick={() => navigateToResult('videos')}
                            className="text-[10px] font-mono text-pink-500 uppercase tracking-wider hover:text-white flex items-center gap-1 select-none"
                          >
                            <span>Launch Video Feeds</span>
                            <CornerDownRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 7. Category Gallery */}
              {(activeFilter === 'all' || activeFilter === 'gallery') && resultsByGroup.gallery.length > 0 && (
                <div className="space-y-4 text-left">
                  <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black border-b border-white/5 pb-2">
                    <ImageIcon className="h-4 w-4 text-pink-500" />
                    <span>Concept Screens & Trailer Frames ({resultsByGroup.gallery.length})</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {resultsByGroup.gallery.map(item => {
                      const titleVal = 'title' in item ? item.title : `Frame at ${item.timestamp}`;
                      const descVal = item.description || '';
                      
                      return (
                        <div 
                          key={item.uniqueId} 
                          className="bg-black border border-white/10 p-4 flex flex-col justify-between space-y-4 hover:border-pink-500/30 transition-all duration-200 group"
                        >
                          <div className="space-y-3">
                            {/* Image container */}
                            {item.imageUrl && (
                              <div className="w-full h-40 relative overflow-hidden bg-zinc-900 border border-white/5">
                                <img 
                                  src={item.imageUrl} 
                                  alt={titleVal} 
                                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                                  referrerPolicy="no-referrer"
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
                                <div className="absolute top-2 right-2">
                                  <span className="text-[8px] font-mono bg-black/80 text-pink-400 px-2 py-0.5 border border-pink-500/20 uppercase tracking-wider">
                                    {item.isFrame ? 'TRAILER FRAME' : 'CONCEPT'}
                                  </span>
                                </div>
                              </div>
                            )}

                            <div className="space-y-1">
                              {/* Extra category/timestamp */}
                              {item.isFrame ? (
                                <span className="text-[9px] font-mono text-zinc-500">TIMESTAMP: {item.timestamp}</span>
                              ) : (
                                <span className="text-[9px] font-mono text-zinc-500 uppercase">CATEGORY: {item.category}</span>
                              )}

                              <h3 className="text-sm font-mono font-bold text-white uppercase tracking-tight">
                                <Highlight text={titleVal} query={query} />
                              </h3>
                              
                              <p className="text-zinc-400 text-[11px] leading-relaxed line-clamp-2">
                                <Highlight text={descVal} query={query} />
                              </p>

                              {/* Spotted / Easter Eggs highlights */}
                              {!item.isFrame && 'spottedElement' in item && (
                                <p className="text-[10px] text-pink-400 font-sans italic pt-1 leading-normal">
                                  <Highlight text={item.spottedElement} query={query} />
                                </p>
                              )}

                              {item.isFrame && 'easterEggs' in item && item.easterEggs && (
                                <div className="pt-1">
                                  <span className="text-[8px] font-mono text-zinc-500 block">Easter Eggs:</span>
                                  <ul className="list-none pl-0 space-y-0.5">
                                    {item.easterEggs.slice(0, 1).map((egg, egIdx) => (
                                      <li key={egIdx} className="text-[10px] text-zinc-500 line-clamp-1 italic">
                                        • <Highlight text={egg} query={query} />
                                      </li>
                                    ))}
                                  </ul>
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="flex justify-end pt-2 border-t border-white/5">
                            <button
                              onClick={() => navigateToResult(item.isFrame ? 'breakdown' : 'gallery')}
                              className="text-[10px] font-mono text-pink-400 uppercase tracking-wider hover:text-white flex items-center gap-1 select-none"
                            >
                              <span>Inspect Media</span>
                              <CornerDownRight className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 8. Category FAQ */}
              {(activeFilter === 'all' || activeFilter === 'faq') && resultsByGroup.faq.length > 0 && (
                <div className="space-y-4 text-left">
                  <div className="flex items-center space-x-2 text-[10px] font-mono text-zinc-500 uppercase tracking-widest font-black border-b border-white/5 pb-2">
                    <HelpCircle className="h-4 w-4 text-pink-500" />
                    <span>Frequently Asked Questions ({resultsByGroup.faq.length})</span>
                  </div>
                  
                  <div className="space-y-3">
                    {resultsByGroup.faq.map(faq => (
                      <div 
                        key={faq.id} 
                        className="bg-black border border-white/10 p-5 flex flex-col justify-between space-y-4 hover:border-pink-500/30 transition-all duration-200"
                      >
                        <div className="space-y-2">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[9px] font-mono text-zinc-500 uppercase bg-white/5 px-2 py-0.5 border border-white/5">
                              {faq.category}
                            </span>
                            <span className={`px-2 py-0.5 text-[9px] font-mono uppercase tracking-wider border flex items-center gap-1 ${
                              faq.verified 
                                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                                : 'bg-yellow-500/10 border-yellow-500/20 text-yellow-400'
                            }`}>
                              {faq.verified ? 'Verified Answer' : 'Speculative Info'}
                            </span>
                          </div>

                          <h3 className="text-base font-sans font-bold text-white">
                            Q: <Highlight text={faq.question} query={query} />
                          </h3>

                          <p className="text-zinc-300 text-xs leading-relaxed font-sans bg-zinc-950 p-3 border border-white/5">
                            <strong>A:</strong> <Highlight text={faq.answer} query={query} />
                          </p>

                          {faq.communityNote && (
                            <p className="text-zinc-500 text-[11px] leading-normal pl-2 border-l border-pink-500/20 font-sans">
                              <span className="font-mono text-pink-500 uppercase text-[9px] font-black tracking-wide block mb-0.5">Community Intelligence:</span>
                              <Highlight text={faq.communityNote} query={query} />
                            </p>
                          )}
                        </div>

                        <div className="flex justify-end pt-2 border-t border-white/5">
                          <button
                            onClick={() => navigateToResult('faq')}
                            className="text-[10px] font-mono text-pink-500 uppercase tracking-wider hover:text-white flex items-center gap-1 select-none"
                          >
                            <span>Access Full FAQ Deck</span>
                            <CornerDownRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </motion.div>
          )}
        </AnimatePresence>

      </div>

    </div>
  );
}

