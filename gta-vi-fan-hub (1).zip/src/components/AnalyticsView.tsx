import { useState } from 'react';
import { 
  Eye, Trophy, ShieldCheck, Flame, ChevronRight
} from 'lucide-react';

export default function AnalyticsView() {
  const [activeRange, setActiveRange] = useState<'7d' | '30d' | 'all'>('7d');

  // Most Viewed News (no views/placeholder metrics)
  const viewedNews = [
    { title: "Rockstar Trailer 2 Video Assets Staged" },
    { title: "Florida Keys Geological Overlay Map 1:1" },
    { title: "RAGE 9 Physics Engine Variable Leaks" },
    { title: "NPC Reaction Weather Tan-line Shaders" }
  ];

  // Trending searches (no query counts/momentum)
  const trendingSearches = [
    { tag: "Trailer 2" },
    { tag: "Lucia Actor" },
    { tag: "Vice City Map" },
    { tag: "Preorder Price" },
    { tag: "Jason Face Mesh" }
  ];

  // Most Trusted Sources (Consensus leaderboards based on official credentials)
  const trustedSources = [
    { name: "Tez2 (@TezFunz2)", score: 96, category: "Game Files & CDNs", badge: "TIER 1 ELITE" },
    { name: "Leonida Mapping Project", score: 92, category: "Coordinate Mapping", badge: "COMMUNITY HUB" },
    { name: "Legacy Forums Admin", score: 88, category: "Developer Comments", badge: "VERIFIED MOD" },
    { name: "Take-Two Investor Portal", score: 99, category: "Official Shareholder Reports", badge: "GOVERNMENT REGISTRY" }
  ];

  return (
    <div className="space-y-8 pb-12 max-w-7xl mx-auto" id="analytics-observatory-root">
      
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4">
        <div>
          <span className="text-pink-500 font-mono text-[10px] tracking-widest uppercase font-black block mb-1">
            TERMINAL DATA MONITORING DECK
          </span>
          <h1 className="text-3xl sm:text-5xl font-display font-black text-white tracking-tighter uppercase leading-none">
            Analytics Observatory
          </h1>
          <p className="text-zinc-400 text-sm mt-2 max-w-3xl font-sans text-left">
            Observe compiled consensus ratings, trending search terms, and verified database directories curated across our active nodes.
          </p>
        </div>

        {/* Filters */}
        <div className="flex bg-[#050505] border border-white/10 p-1 font-mono text-[10px] uppercase select-none shrink-0 self-start sm:self-auto">
          {[
            { id: '7d', label: '7 Days' },
            { id: '30d', label: '30 Days' },
            { id: 'all', label: 'Max' }
          ].map((range) => (
            <button
              key={range.id}
              onClick={() => setActiveRange(range.id as any)}
              className={`px-3 py-1.5 transition-colors ${
                activeRange === range.id 
                  ? 'bg-pink-500 text-black font-black' 
                  : 'text-zinc-500 hover:text-white'
              }`}
            >
              {range.label}
            </button>
          ))}
        </div>
      </div>

      {/* Database Connection Notice / Zero-Analytics Block */}
      <div className="bg-black border border-white/10 p-6 sm:p-8 space-y-4 text-left relative overflow-hidden" id="analytics-db-status">
        <div className="absolute top-0 left-0 w-full h-[2px] bg-pink-500" />
        <div className="flex items-center space-x-3 text-pink-500 font-mono text-[10px] tracking-widest uppercase font-black">
          <ShieldCheck className="h-4 w-4 text-pink-500 shrink-0" />
          <span>ANALYTICS ENGINE STATUS</span>
        </div>
        <h2 className="text-xl sm:text-2xl font-display font-black text-white uppercase tracking-tight">
          Live Traffic Analytics & Visitor Counters are Offline
        </h2>
        <p className="text-zinc-400 text-xs sm:text-sm max-w-4xl leading-relaxed font-sans">
          This static client-side fan hub does not integrate tracking cookies, tracking pixels, or external telemetry databases. 
          To adhere to strict user privacy standards and our no-fake-data policy, all traffic charts, device metrics, and unique visitor counts are hidden until a production cloud database is provisioned.
        </p>
      </div>

      {/* Grid: Most Viewed, Trending Searches, Most Trusted */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
        
        {/* Most Viewed News */}
        <div className="bg-black border border-white/10 p-5 space-y-4">
          <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
            <h3 className="font-display font-black text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Eye className="h-4 w-4 text-pink-500" />
              <span>Most Viewed Dossiers</span>
            </h3>
            <span className="text-[9px] font-mono text-zinc-500 uppercase">STATUS</span>
          </div>

          <div className="space-y-4">
            {viewedNews.map((news, idx) => (
              <div key={idx} className="p-3 bg-[#050505] border border-white/5 hover:border-pink-500/20 transition-colors flex items-center justify-between font-mono text-xs">
                <span className="text-white font-bold leading-tight line-clamp-1">{news.title}</span>
                <ChevronRight className="h-4 w-4 text-zinc-600 shrink-0" />
              </div>
            ))}
          </div>
        </div>

        {/* Trending Searches */}
        <div className="bg-black border border-white/10 p-5 space-y-4">
          <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
            <h3 className="font-display font-black text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Flame className="h-4 w-4 text-orange-500" />
              <span>Trending Queries</span>
            </h3>
            <span className="text-[9px] font-mono text-zinc-500 uppercase">MOMENTUM</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {trendingSearches.map((search, idx) => (
              <div key={idx} className="p-3 bg-[#050505] border border-white/5 hover:border-pink-500/20 transition-colors flex items-center justify-between">
                <span className="text-white font-bold block uppercase">{search.tag}</span>
                <span className="text-[8px] font-black px-1.5 py-0.5 border uppercase border-zinc-800 text-zinc-500 bg-zinc-950">
                  TRENDING
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Most Trusted Sources */}
        <div className="bg-black border border-white/10 p-5 space-y-4">
          <div className="flex justify-between items-center border-b border-white/5 pb-2.5">
            <h3 className="font-display font-black text-xs uppercase tracking-widest text-white flex items-center gap-2">
              <Trophy className="h-4 w-4 text-emerald-400" />
              <span>Consensus Registry</span>
            </h3>
            <span className="text-[9px] font-mono text-zinc-500 uppercase">SCORE</span>
          </div>

          <div className="space-y-3 font-mono text-xs">
            {trustedSources.map((source, idx) => (
              <div key={idx} className="p-3 bg-[#050505] border border-white/5 flex flex-col justify-between gap-2.5">
                <div className="space-y-0.5">
                  <span className="text-white font-bold block">{source.name}</span>
                  <span className="text-[9px] text-zinc-500 block">{source.category}</span>
                </div>

                <div className="flex justify-between items-center border-t border-white/5 pt-2">
                  <span className="text-[8px] text-zinc-500 uppercase font-black tracking-widest">{source.badge}</span>
                  <span className="text-emerald-400 font-black">{source.score}% accuracy</span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
}
