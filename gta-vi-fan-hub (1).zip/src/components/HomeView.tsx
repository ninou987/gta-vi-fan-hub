import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, Flame, ExternalLink, Calendar, Heart, MessageSquare, 
  ShieldAlert, Sparkles, User, HelpCircle, X, TrendingUp, 
  ShieldCheck, Clock, Image as ImageIcon, Video, Eye, Check,
  ChevronRight, ArrowUpRight, Zap, RefreshCw, ThumbsUp
} from 'lucide-react';
import { socialFeedData, timelineEventsData, trailerFramesData } from '../data/gtaData';
import TrustBadge from './TrustBadge';

interface HomeViewProps {
  setView: (view: string) => void;
}

const COUNTDOWN_TARGETS = [
  { id: 'preorder', label: 'Official Pre-order Alert & Wishlist Tracker', date: '2026-07-06T10:00:00', note: 'Official retail pre-orders have not yet been launched by Rockstar Games. This tracker allows you to set up simulated alerts and wishlist preferences.' },
  { id: 'release', label: 'Speculative Fall 2026 Community Tracking', date: '2026-11-17T00:00:00', note: 'Rockstar Games originally targeted Fall 2025; our community tracker monitors late 2026 as a highly probable speculative launch window.' },
  { id: 'trailer2', label: 'Keynote Marketing Trailer 2 Speculation', date: '2026-10-15T15:00:00', note: 'Historically aligned with Rockstar Games autumnal cinematic announcements.' },
  { id: 'pc', label: 'Speculated PC Port Release Window', date: '2027-11-20T00:00:00', note: 'Based on standard Rockstar Games console-to-desktop distribution offsets of 12 to 18 months.' }
];

const LATEST_VIDEOS = [
  {
    id: 'v1',
    title: 'Grand Theft Auto VI Trailer 1 (Official Reveal)',
    duration: '1:30',
    views: '210M',
    channel: 'Rockstar Games',
    date: 'Dec 4, 2023',
    embedId: 'QdBZY2fkU-0',
    category: 'Official Cinematic',
    thumbnail: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=600'
  },
  {
    id: 'v2',
    title: 'Tom Petty - Love Is A Long Road (Official Trailer Soundtrack)',
    duration: '4:08',
    views: '45M',
    channel: 'Tom Petty & The Heartbreakers',
    date: 'Dec 5, 2023',
    embedId: '2gK3s5X9_N0',
    category: 'Soundtrack Audio',
    thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=800'
  },
  {
    id: 'v3',
    title: 'Mapping Leonida: Community Speculative Overlay Walkthrough',
    duration: '12:45',
    views: '1.2M',
    channel: 'Leonida Cartography Club',
    embedId: 'QdBZY2fkU-0', // Backed to Trailer 1 as a placeholder or related gameplay
    category: 'Mapping Speculation',
    thumbnail: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=600'
  }
];

export default function HomeView({ setView }: HomeViewProps) {
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);
  const [activeTargetId, setActiveTargetId] = useState<string>('preorder');
  const [isPreorderOpen, setIsPreorderOpen] = useState(false);
  const [preorderPlatform, setPreorderPlatform] = useState<'ps5' | 'xbox'>('ps5');
  const [preorderEdition, setPreorderEdition] = useState<'standard' | 'deluxe' | 'collector'>('standard');
  const [preorderSuccess, setPreorderSuccess] = useState(false);
  
  // Custom states for upgraded features
  const [selectedVideoEmbedId, setSelectedVideoEmbedId] = useState<string | null>(null);
  const [selectedImageId, setSelectedImageId] = useState<number | null>(null);
  const [hoveredEventId, setHoveredEventId] = useState<string | null>(null);
  
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  const selectedTarget = COUNTDOWN_TARGETS.find(t => t.id === activeTargetId) || COUNTDOWN_TARGETS[0];

  // Calculate live countdown to selected target date
  useEffect(() => {
    const targetDate = new Date(selectedTarget.date).getTime();

    const calculateTime = () => {
      const now = new Date().getTime();
      const difference = targetDate - now;

      if (difference <= 0) {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        return;
      }

      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      setTimeLeft({ days, hours, minutes, seconds });
    };

    calculateTime();
    const interval = setInterval(calculateTime, 1000);
    return () => clearInterval(interval);
  }, [activeTargetId, selectedTarget]);

  // Derived datasets for news layout
  // 1. Trending News (Sorted by view count)
  const trendingNews = [...timelineEventsData]
    .sort((a, b) => (b.views || 0) - (a.views || 0))
    .slice(0, 3);

  // 2. Most Trusted News (Sorted by trust score)
  const mostTrustedNews = [...timelineEventsData]
    .sort((a, b) => b.trustScore - a.trustScore)
    .slice(0, 3);

  // 3. Latest Official News
  const latestOfficialNews = [...timelineEventsData]
    .filter(e => e.category === 'official')
    .slice(0, 3);

  // 4. Recently Updated (Sorted by simulated parsing of lastVerified strings)
  const recentlyUpdated = [...timelineEventsData]
    .sort((a, b) => b.lastVerified.localeCompare(a.lastVerified))
    .slice(0, 3);

  // Featured News Asset (e.g., t3)
  const featuredArticle = timelineEventsData.find(e => e.id === 't3') || timelineEventsData[0];

  const quickFacts = [
    { label: 'Confirmed Location', value: 'State of Leonida (Vice City & counties)', desc: 'Heavily inspired by Florida, featuring deep wetlands, coastal keys, and neon cityscapes.' },
    { label: 'Lead Protagonists', value: 'Lucia & Jason (Dual Co-op)', desc: 'A Bonnie and Clyde-style duo navigating heist ventures, street gangs, and high-speed pursuits.' },
    { label: 'Target Launch', value: 'Fall 2025 / Early 2026', desc: 'Parent company Take-Two has locked Fall 2025 in recent financial forecasting conferences.' },
    { label: 'Engine Upgrade', value: 'RAGE Engine v9', desc: 'Next-generation physics, unprecedented ocean shader fidelity, and highly reactive AI systems.' },
    { label: 'Target Platforms', value: 'PlayStation 5 | Xbox Series X|S', desc: 'Designed natively from the ground up for current-gen ultra-high speed console storage architectures.' },
  ];

  const activeImageFrame = trailerFramesData.find(f => f.id === selectedImageId);

  return (
    <div className="space-y-16 lg:space-y-24 pb-16" id="home-view-container">
      
      {/* 1. UPGRADED BETTER HERO SECTION */}
      <section className="relative overflow-hidden rounded-none bg-black border border-white/10" id="hero-trailer-panel">
        {/* Decorative elements */}
        <div className="absolute inset-y-0 left-0 w-2 bg-gradient-to-b from-pink-500 via-purple-600 to-orange-400" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-pink-500/15 via-orange-500/5 to-transparent pointer-events-none" />
        {/* Tech line grid overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 p-6 sm:p-10 lg:p-14 items-center relative z-10">
          
          {/* Hero Pitch */}
          <div className="lg:col-span-5 space-y-6 lg:space-y-8 text-left">
            <div className="inline-flex items-center space-x-2 bg-pink-500 px-3 py-1.5 text-[10px] font-mono font-black text-black tracking-widest uppercase shadow-[0_0_15px_rgba(236,72,153,0.3)]">
              <Sparkles className="h-3.5 w-3.5 shrink-0" />
              <span>THE FIRST LOOK IN 10 YEARS</span>
            </div>
            
            <div className="space-y-3">
              <span className="font-mono text-zinc-500 text-xs tracking-widest uppercase font-bold block">★ WELCOME TO LEONIDA STATE ★</span>
              <h1 className="font-display text-4xl sm:text-6xl font-black tracking-tighter text-white uppercase leading-none">
                WELCOME BACK TO <br />
                <span className="bg-gradient-to-r from-pink-500 via-purple-400 to-orange-400 bg-clip-text text-transparent block drop-shadow-[0_2px_10px_rgba(236,72,153,0.15)]">
                  VICE CITY
                </span>
              </h1>
            </div>
            
            <p className="text-zinc-400 text-sm md:text-base leading-relaxed max-w-md font-sans">
              Grand Theft Auto VI heads to the state of Leonida, home to the neon-soaked streets of Vice City and beyond, in the most immersive evolution of the Grand Theft Auto series yet. Explore confirmed coordinates, analyzed timelines, and community-proven research metrics.
            </p>

            <div className="flex flex-wrap gap-3 pt-2">
              <button 
                onClick={() => setIsPlayingVideo(true)}
                className="group flex items-center space-x-2.5 rounded-none bg-gradient-to-r from-pink-500 to-purple-600 px-6 py-4 text-xs font-display font-black uppercase tracking-wider text-black hover:brightness-110 active:scale-95 transition-all shadow-[0_0_20px_rgba(236,72,153,0.2)]"
                id="watch-trailer-hero-btn"
              >
                <Play className="h-4.5 w-4.5 fill-current text-black group-hover:scale-110 transition-transform" />
                <span>Watch Official Trailer 1</span>
              </button>
              
              <button 
                onClick={() => setView('breakdown')}
                className="flex items-center space-x-2 rounded-none bg-zinc-950 hover:bg-zinc-900 px-5 py-4 text-xs font-display font-black uppercase tracking-wider text-white border border-white/10 hover:border-pink-500/40 transition-colors"
                id="breakdown-tab-link-btn"
              >
                <span>Timestamps Analysis</span>
              </button>
            </div>

            {/* Tom Petty Tribute Tag */}
            <div className="pt-4 border-t border-white/5 flex items-center space-x-3 text-[11px] text-zinc-500 font-mono">
              <span className="inline-block h-2 w-2 rounded-none bg-orange-500 animate-pulse" />
              <span>SOUNDTRACK DIRECTIVE: TOM PETTY - "LOVE IS A LONG ROAD"</span>
            </div>
          </div>

          {/* Video / Interactive Poster Area */}
          <div className="lg:col-span-7" id="trailer-player-box">
            <div className="aspect-video w-full rounded-none overflow-hidden border border-white/10 bg-black shadow-2xl relative group">
              
              {/* Scanline overlay effect */}
              <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[size:100%_4px,3px_100%] pointer-events-none z-10 opacity-40" />

              {!isPlayingVideo ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center">
                  <div className="absolute inset-0 bg-cover bg-center opacity-40 filter brightness-50 group-hover:scale-[1.02] transition-transform duration-700" style={{ backgroundImage: `url('https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&q=80&w=800')` }} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                  
                  {/* Floating play badge */}
                  <button 
                    onClick={() => setIsPlayingVideo(true)}
                    className="relative z-10 bg-white p-6 text-black hover:bg-pink-500 hover:text-black transition-all duration-300 hover:scale-110 active:scale-95 shadow-[0_0_40px_rgba(236,72,153,0.4)] border border-pink-500"
                    id="play-video-overlay-btn"
                  >
                    <Play className="h-10 w-10 fill-current translate-x-0.5 text-black" />
                  </button>
                  <span className="relative z-10 mt-6 text-white font-display font-black tracking-widest text-sm uppercase">Click to stream reveal trailer</span>
                  <span className="relative z-10 text-pink-500 text-[10px] font-mono tracking-widest uppercase mt-2 bg-black/85 px-3 py-1 border border-white/5">210M+ VIEWS AND COUNTING</span>
                </div>
              ) : (
                <iframe
                  title="GTA VI Trailer 1"
                  className="w-full h-full"
                  src="https://www.youtube.com/embed/QdBZY2fkU-0?autoplay=1"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              )}
            </div>
          </div>

        </div>
      </section>

      {/* 2. UPGRADED BREAKING NEWS MARQUEE TICKER */}
      <div className="bg-red-950/20 border-y border-red-500/30 py-3 overflow-hidden relative" id="breaking-ticker-marquee">
        <style>{`
          @keyframes marquee {
            0% { transform: translateX(0%); }
            100% { transform: translateX(-50%); }
          }
          .animate-marquee {
            display: flex;
            width: max-content;
            animation: marquee 40s linear infinite;
          }
        `}</style>
        <div className="absolute left-0 top-0 bottom-0 bg-red-600 text-black px-4.5 py-1 flex items-center font-display font-black text-[10px] tracking-widest uppercase z-20 border-r border-red-500/50">
          <Flame className="h-3.5 w-3.5 mr-1.5 animate-pulse" />
          <span>ALERTS & BULLETIN</span>
        </div>
        <div className="animate-marquee whitespace-nowrap gap-16 text-[10px] font-mono uppercase text-red-400 pl-32">
          <span>● [CONSENSUS UPDATE]: TAKE-TWO INTERACTIVE RE-AFFIRMS SPECULATIVE FALL 2025 TIMEFRAME TO SHAREHOLDERS</span>
          <span>● [TRAILER INSIGHT]: NEW NPC ARTIFICIAL INTEL PATENTS POINT TO PROCEDURAL BEHAVIORS FOR BEACH CROWDS</span>
          <span>● [COORDINATE SCAN]: 144 SQUARE KILOMETERS OF LEONIDA TERRAIN COMPILED BY MapSpec ENGINE</span>
          <span>● [RUMOR VERDICT]: DEBUNKED $150 RETAIL TAG ORIGINATED FROM FAN DISCORD GRAPHIC ASSEMBLY</span>
          <span>● [CONSENSUS UPDATE]: TAKE-TWO INTERACTIVE RE-AFFIRMS SPECULATIVE FALL 2025 TIMEFRAME TO SHAREHOLDERS</span>
          <span>● [TRAILER INSIGHT]: NEW NPC ARTIFICIAL INTEL PATENTS POINT TO PROCEDURAL BEHAVIORS FOR BEACH CROWDS</span>
          <span>● [COORDINATE SCAN]: 144 SQUARE KILOMETERS OF LEONIDA TERRAIN COMPILED BY MapSpec ENGINE</span>
          <span>● [RUMOR VERDICT]: DEBUNKED $150 RETAIL TAG ORIGINATED FROM FAN DISCORD GRAPHIC ASSEMBLY</span>
        </div>
      </div>

      {/* 3. DYNAMIC COUNTDOWN CARDS WITH ACTIVE EVENT SELECTOR */}
      <section className="space-y-6" id="countdown-timer-module">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center space-x-2 text-left">
            <Calendar className="h-5 w-5 text-pink-500" />
            <h2 className="text-sm font-display font-black text-white tracking-widest uppercase">Leonida Countdown System</h2>
          </div>
          
          {/* Target Event Toggles */}
          <div className="flex flex-wrap gap-1 bg-zinc-950 p-1 border border-white/5 self-start">
            {COUNTDOWN_TARGETS.map((target) => (
              <button
                key={target.id}
                onClick={() => setActiveTargetId(target.id)}
                className={`px-3 py-1.5 text-[9px] font-mono uppercase font-black transition-all ${
                  activeTargetId === target.id
                    ? 'bg-pink-600 text-black'
                    : 'text-zinc-500 hover:text-zinc-300 hover:bg-white/5'
                }`}
              >
                {target.id}
              </button>
            ))}
          </div>
        </div>

        <div className="bg-[#050505] border border-white/5 p-5 sm:p-6 rounded-none space-y-6 relative">
          <div className="absolute top-0 right-0 h-[2px] bg-gradient-to-r from-pink-500/20 via-orange-400/20 to-transparent left-0" />
          
          <div className="text-[10px] font-mono text-zinc-400 flex flex-wrap items-center gap-2">
            <span className="text-pink-500 font-bold uppercase">Active Target Coordinate:</span>
            <span className="text-white font-black">{selectedTarget.label}</span>
            <span className="text-zinc-600">— Speculated timestamp ({selectedTarget.date.split('T')[0]})</span>
          </div>

          {activeTargetId === 'preorder' ? (
            <div className="border border-pink-500/30 bg-pink-500/5 p-6 sm:p-8 text-center space-y-4 relative overflow-hidden">
              {/* Corner accent */}
              <div className="absolute top-0 right-0 bg-pink-500 text-black font-mono text-[9px] font-black uppercase tracking-widest px-4 py-1.5">
                ALERT REGISTRATION STANDBY
              </div>
              
              <div className="space-y-2">
                <span className="text-pink-500 font-mono text-xs uppercase tracking-widest font-black animate-pulse block">
                  ★★★★★ PRE-ORDER WISH-LIST & ALERTS ★★★★★
                </span>
                <h3 className="text-2xl sm:text-4xl font-display font-black text-white uppercase tracking-tighter leading-tight">
                  Pre-orders are Unannounced
                </h3>
                <p className="text-zinc-400 text-xs sm:text-sm max-w-xl mx-auto font-sans leading-relaxed">
                  Official pre-orders have not yet been launched by Rockstar Games. Register your preferences today to receive instant notifications the moment official retail channels go live.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row justify-center items-center gap-3 pt-4">
                <button
                  onClick={() => {
                    setPreorderSuccess(false);
                    setIsPreorderOpen(true);
                  }}
                  className="w-full sm:w-auto bg-gradient-to-r from-pink-500 to-orange-400 hover:brightness-110 text-black font-display font-black text-xs uppercase tracking-widest px-8 py-4.5 transition-all hover:scale-[1.01] active:scale-[0.99] shadow-[0_4px_20px_rgba(236,72,153,0.15)]"
                  id="countdown-preorder-now-btn"
                >
                  Register Alert / Wishlist
                </button>
                <div className="flex gap-2">
                  <span className="bg-zinc-900 border border-white/5 text-zinc-400 font-mono text-[9px] uppercase px-3 py-2 font-black">PS5 COMPATIBLE</span>
                  <span className="bg-zinc-900 border border-white/5 text-zinc-400 font-mono text-[9px] uppercase px-3 py-2 font-black">XBOX SERIES X|S</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: 'Days Remaining', value: timeLeft.days, color: 'border-pink-500/20 text-pink-500 bg-pink-950/10' },
                { label: 'Hours Remaining', value: timeLeft.hours, color: 'border-orange-500/20 text-orange-400 bg-orange-950/10' },
                { label: 'Minutes Remaining', value: timeLeft.minutes, color: 'border-cyan-500/20 text-cyan-400 bg-cyan-950/10' },
                { label: 'Seconds Remaining', value: timeLeft.seconds, color: 'border-white/10 text-white bg-white/5' },
              ].map((card, idx) => (
                <div 
                  key={idx}
                  className={`rounded-none border ${card.color} p-6 sm:p-8 text-center backdrop-blur-sm relative overflow-hidden group`}
                  id={`countdown-card-${card.label.toLowerCase()}`}
                >
                  <div className="font-mono text-4xl sm:text-6xl font-black tracking-tighter mb-2 leading-none group-hover:scale-105 transition-transform duration-300">
                    {card.value.toString().padStart(2, '0')}
                  </div>
                  <div className="text-zinc-500 text-[9px] font-mono uppercase tracking-widest">{card.label}</div>
                </div>
              ))}
            </div>
          )}

          <p className="text-zinc-500 text-[10px] font-mono leading-relaxed text-left border-t border-white/5 pt-3">
            <span className="text-zinc-400 font-black">CONSENSUS EVALUATION NOTE:</span> {selectedTarget.note}
          </p>
        </div>
      </section>

      {/* 4. UPGRADED FEATURED ARTICLE SECTION */}
      <section className="space-y-4" id="featured-article-container">
        <div className="flex items-center space-x-2 text-left">
          <Sparkles className="h-5 w-5 text-pink-500" />
          <h2 className="text-sm font-display font-black text-white tracking-widest uppercase">Spotlight Intelligence Dossier</h2>
        </div>

        <div className="bg-gradient-to-br from-[#020202] to-zinc-950 border border-white/10 p-5 sm:p-8 space-y-6 relative overflow-hidden group">
          {/* Aesthetic pink border glow indicator */}
          <div className="absolute top-0 inset-x-0 h-[2px] bg-pink-500" />
          <div className="absolute top-0 right-0 bg-pink-600 text-black font-mono text-[9px] font-black uppercase tracking-widest px-4 py-1.5 border-b border-l border-white/10">
            ★ CURATED PLATFORM ESSENTIAL
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-8 items-center text-left">
            {/* Left Image aspect (4 cols) */}
            <div className="lg:col-span-5 aspect-video bg-cover bg-center border border-white/10 relative group-hover:border-pink-500/40 transition-colors" style={{ backgroundImage: `url('${featuredArticle.imageUrl}')` }}>
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
              <div className="absolute bottom-3 left-3 flex flex-wrap gap-1.5">
                <TrustBadge badge={featuredArticle.trustBadge} size="sm" />
                <span className="bg-black/90 px-2 py-1 text-[8px] font-mono text-zinc-400 border border-white/10 font-bold uppercase">
                  {featuredArticle.trustScore}% CONSENSUS SCORE
                </span>
              </div>
            </div>
            
            {/* Right details content (7 cols) */}
            <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <div className="flex flex-wrap items-center gap-3 text-[10px] font-mono text-zinc-500 font-bold">
                  <span className="text-zinc-400 uppercase">{featuredArticle.date}</span>
                  <span>•</span>
                  <span>{featuredArticle.readingTime} MIN READ</span>
                  <span>•</span>
                  <span>{featuredArticle.views?.toLocaleString() || '45,000'} SPECTATORS</span>
                </div>
                
                <h3 className="text-2xl sm:text-3xl font-display font-black text-white uppercase tracking-tight group-hover:text-pink-500 transition-colors leading-tight">
                  {featuredArticle.title}
                </h3>
                
                <p className="text-zinc-400 text-xs sm:text-sm leading-relaxed font-sans">
                  {featuredArticle.details}
                </p>
              </div>
              
              <div className="pt-2 border-t border-white/5 flex flex-wrap items-center justify-between gap-4">
                <div className="flex flex-wrap gap-1.5">
                  {featuredArticle.tags.map(tag => (
                    <span key={tag} className="px-2.5 py-0.5 bg-zinc-900 border border-white/5 text-zinc-500 font-mono text-[9px] uppercase">
                      #{tag}
                    </span>
                  ))}
                </div>
                
                <button
                  onClick={() => setView('news')}
                  className="group inline-flex items-center space-x-1 text-xs font-mono font-black text-pink-500 hover:text-pink-400 uppercase tracking-wider"
                >
                  <span>Launch Deep Intel Dossier</span>
                  <ChevronRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. NEWS BENTO SYSTEM: TRENDING, MOST TRUSTED, OFFICIAL, UPDATED */}
      <section className="space-y-8" id="news-bento-system">
        <div className="flex items-center space-x-2 text-left">
          <TrendingUp className="h-5 w-5 text-cyan-400" />
          <h2 className="text-sm font-display font-black text-white tracking-widest uppercase">Live News Intelligence Columns</h2>
        </div>

        {/* 2x2 Grid for standard, but responsive to single column on mobile */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* COLUMN A: TRENDING NEWS (Top views) */}
          <div className="bg-[#050505] border border-white/10 p-5 sm:p-6 space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center space-x-2">
                <Flame className="h-4 w-4 text-orange-500" />
                <span className="font-display font-black text-xs uppercase text-white tracking-wider">Trending Intelligence</span>
              </div>
              <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold">VIEWS DEMAND</span>
            </div>

            <div className="divide-y divide-white/5">
              {trendingNews.map((article, index) => (
                <div 
                  key={article.id}
                  className="py-4 first:pt-0 last:pb-0 group/trend cursor-pointer flex gap-4 items-start"
                  onClick={() => setView('news')}
                >
                  <span className="font-display font-black text-2xl text-zinc-700 group-hover/trend:text-pink-500 transition-colors">
                    {String(index + 1).padStart(2, '0')}
                  </span>
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono text-zinc-500 font-bold uppercase">{article.date}</span>
                      <TrustBadge badge={article.trustBadge} size="sm" className="scale-75 origin-left" />
                    </div>
                    <h4 className="text-white text-sm font-bold group-hover/trend:text-pink-400 transition-colors uppercase tracking-tight line-clamp-1">
                      {article.title}
                    </h4>
                    <p className="text-zinc-500 text-xs font-sans line-clamp-1 leading-snug">{article.summary}</p>
                    <div className="flex items-center space-x-3 text-[10px] font-mono text-zinc-600">
                      <span className="flex items-center gap-1">
                        <Eye className="h-3 w-3" />
                        {article.views?.toLocaleString() || '45,000'} views
                      </span>
                      <span>Consensus: {article.trustScore}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* COLUMN B: MOST TRUSTED NEWS (High trust score) */}
          <div className="bg-[#050505] border border-white/10 p-5 sm:p-6 space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center space-x-2">
                <ShieldCheck className="h-4 w-4 text-emerald-400" />
                <span className="font-display font-black text-xs uppercase text-white tracking-wider">Most Verified Consensus</span>
              </div>
              <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold">CONFIDENCE RATE</span>
            </div>

            <div className="divide-y divide-white/5">
              {mostTrustedNews.map((article) => (
                <div 
                  key={article.id}
                  className="py-4 first:pt-0 last:pb-0 group/trust cursor-pointer flex gap-4 items-start"
                  onClick={() => setView('news')}
                >
                  {/* Circle Meter Progress */}
                  <div className="relative h-10 w-10 shrink-0 border border-white/10 bg-black flex items-center justify-center font-mono text-xs font-black text-pink-500">
                    <div className="absolute top-0 right-0 h-1.5 w-1.5 bg-emerald-400" />
                    <span>{article.trustScore}%</span>
                  </div>
                  
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono text-zinc-500 font-bold uppercase">{article.date}</span>
                      <TrustBadge badge={article.trustBadge} size="sm" className="scale-75 origin-left" />
                    </div>
                    <h4 className="text-white text-sm font-bold group-hover/trend:text-pink-400 transition-colors uppercase tracking-tight line-clamp-1">
                      {article.title}
                    </h4>
                    <p className="text-zinc-500 text-xs font-sans line-clamp-1 leading-snug">{article.summary}</p>
                    <span className="text-[9px] font-mono text-emerald-500 uppercase block font-black">
                      AUDIT STATUS: FULLY CERTIFIED CONFORMITY
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* COLUMN C: LATEST OFFICIAL NEWS */}
          <div className="bg-[#050505] border border-white/10 p-5 sm:p-6 space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center space-x-2">
                <Zap className="h-4 w-4 text-pink-500" />
                <span className="font-display font-black text-xs uppercase text-white tracking-wider">Latest Official Bulletins</span>
              </div>
              <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold">DEVELOPER FEED</span>
            </div>

            <div className="divide-y divide-white/5">
              {latestOfficialNews.map((article) => (
                <div 
                  key={article.id}
                  className="py-4 first:pt-0 last:pb-0 group/off cursor-pointer space-y-1.5"
                  onClick={() => setView('news')}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[9px] font-mono text-zinc-500 font-bold uppercase">{article.date}</span>
                    <TrustBadge badge="official" size="sm" className="scale-75 origin-right" />
                  </div>
                  <h4 className="text-white text-sm font-bold group-hover/off:text-pink-400 transition-colors uppercase tracking-tight line-clamp-1">
                    {article.title}
                  </h4>
                  <p className="text-zinc-400 text-xs font-sans line-clamp-2 leading-relaxed">{article.summary}</p>
                  <div className="flex items-center gap-1 text-[9px] font-mono text-zinc-600 uppercase font-bold">
                    <span>Newswire Source Verified</span>
                    <span>•</span>
                    <span>100% Reliability Matrix</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* COLUMN D: RECENTLY UPDATED (Verification Status Changes) */}
          <div className="bg-[#050505] border border-white/10 p-5 sm:p-6 space-y-4 text-left">
            <div className="flex items-center justify-between border-b border-white/5 pb-3">
              <div className="flex items-center space-x-2">
                <RefreshCw className="h-4 w-4 text-orange-400 animate-spin-slow" />
                <span className="font-display font-black text-xs uppercase text-white tracking-wider">Recently Verified & Debunked</span>
              </div>
              <span className="text-[10px] font-mono text-zinc-500 uppercase font-bold">FACT SCAN</span>
            </div>

            <div className="divide-y divide-white/5">
              {recentlyUpdated.map((article) => (
                <div 
                  key={article.id}
                  className="py-4 first:pt-0 last:pb-0 group/up cursor-pointer space-y-1.5"
                  onClick={() => setView('news')}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[9px] font-mono text-zinc-500 font-bold uppercase">LAST AUDIT: {article.lastVerified}</span>
                    <TrustBadge badge={article.trustBadge} size="sm" className="scale-75 origin-right" />
                  </div>
                  <h4 className="text-white text-sm font-bold group-hover/up:text-pink-400 transition-colors uppercase tracking-tight line-clamp-1">
                    {article.title}
                  </h4>
                  <p className="text-zinc-400 text-xs font-sans line-clamp-2 leading-relaxed">{article.summary}</p>
                  <div className="flex items-center justify-between text-[10px] font-mono pt-1">
                    <span className="text-zinc-500">Confidence Factor: {article.confidenceLevel?.toUpperCase() || 'HIGH'}</span>
                    <span className="text-pink-500 font-black group-hover/up:translate-x-1 transition-transform">INSPECT DOSSIER →</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </section>

      {/* 6. LATEST VIDEOS COMPONENT */}
      <section className="space-y-6" id="latest-videos-container">
        <div className="flex items-center space-x-2 text-left">
          <Video className="h-5 w-5 text-pink-500" />
          <h2 className="text-sm font-display font-black text-white tracking-widest uppercase">Latest Cinematic Feeds</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {LATEST_VIDEOS.map((vid) => (
            <div 
              key={vid.id}
              className="bg-zinc-950 border border-white/5 hover:border-pink-500/30 transition-all cursor-pointer group flex flex-col justify-between"
              onClick={() => setSelectedVideoEmbedId(vid.embedId)}
            >
              <div className="aspect-video w-full bg-cover bg-center relative overflow-hidden" style={{ backgroundImage: `url('${vid.thumbnail}')` }}>
                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/10 transition-colors duration-300" />
                
                {/* Floating Play Icon */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="bg-black/85 border border-white/10 p-3.5 text-white group-hover:text-pink-500 group-hover:scale-110 transition-all duration-300">
                    <Play className="h-5 w-5 fill-current text-white" />
                  </span>
                </div>
                
                {/* Length duration */}
                <span className="absolute bottom-2 right-2 bg-black px-2 py-0.5 text-[9px] font-mono text-zinc-300 font-black">
                  {vid.duration}
                </span>

                {/* Tag */}
                <span className="absolute top-2 left-2 bg-pink-600 text-black px-2 py-0.5 text-[8px] font-mono font-black uppercase">
                  {vid.category}
                </span>
              </div>

              <div className="p-4 space-y-2 text-left flex-1 flex flex-col justify-between">
                <div className="space-y-1">
                  <h3 className="text-white text-xs sm:text-sm font-bold uppercase tracking-tight group-hover:text-pink-400 transition-colors leading-tight">
                    {vid.title}
                  </h3>
                  <p className="text-[10px] font-mono text-zinc-500">Channel: {vid.channel}</p>
                </div>

                <div className="flex items-center justify-between text-[10px] font-mono text-zinc-400 border-t border-white/5 pt-2">
                  <span>{vid.date}</span>
                  <span className="text-pink-500 font-bold">{vid.views} spectators</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 7. LATEST IMAGES COMPONENT (TRAILER TIMESTAMPS) */}
      <section className="space-y-6" id="latest-images-container">
        <div className="flex items-center space-x-2 text-left">
          <ImageIcon className="h-5 w-5 text-orange-400" />
          <h2 className="text-sm font-display font-black text-white tracking-widest uppercase">Latest Speculative Captures</h2>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {trailerFramesData.map((frame) => (
            <div 
              key={frame.id}
              className="bg-zinc-950 border border-white/5 hover:border-pink-500/30 transition-all cursor-pointer group overflow-hidden"
              onClick={() => setSelectedImageId(frame.id)}
            >
              <div className="aspect-video bg-cover bg-center relative group-hover:scale-[1.05] transition-transform duration-500" style={{ backgroundImage: `url('${frame.imageUrl}')` }}>
                <div className="absolute inset-0 bg-black/30 group-hover:bg-black/0 transition-colors" />
                <span className="absolute top-1.5 left-1.5 bg-black/80 text-orange-400 text-[8px] font-mono px-1.5 py-0.5 border border-white/10 font-bold">
                  {frame.timestamp}
                </span>
              </div>
              <div className="p-2.5 text-left">
                <h4 className="text-white text-[10px] font-bold tracking-tight line-clamp-1 uppercase group-hover:text-pink-400 transition-colors">
                  {frame.title}
                </h4>
                <div className="flex items-center justify-between text-[8px] font-mono text-zinc-500 mt-1">
                  <span>SEC: {frame.seconds}s</span>
                  <span className="text-pink-500">Inspect →</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 8. BENTO SPLIT SECTION: VIRAL FEED & ESSENTIAL FACTS (PRESERVED) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="home-bento-split">
        
        {/* Leonida Social Feed (Phone mockup representation) - 5 Cols */}
        <section className="lg:col-span-5 space-y-4 lg:sticky lg:top-20">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Flame className="h-5 w-5 text-orange-500" />
              <h2 className="text-sm font-display font-black text-white tracking-widest uppercase">Viral Leonida Feed</h2>
            </div>
            <span className="bg-red-500 px-2.5 py-1 font-mono text-[9px] font-black text-black tracking-widest animate-pulse">
              LIVE BROADCAST
            </span>
          </div>

          {/* Social Phone Mockup */}
          <div className="rounded-none border-2 border-white/10 bg-black p-4 shadow-2xl relative overflow-hidden h-[540px] flex flex-col" id="social-phone-container">
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-orange-400 z-20" />
            
            {/* Scrollable feed list */}
            <div className="flex-1 overflow-y-auto space-y-4 pt-2 pr-1 scrollbar-thin scrollbar-thumb-zinc-800">
              {socialFeedData.map((post) => (
                <div 
                  key={post.id} 
                  className="rounded-none bg-[#09090b] border border-white/5 p-4 space-y-3 relative overflow-hidden text-left"
                  id={`social-post-${post.id}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2.5">
                      <div className="h-8 w-8 bg-pink-600 flex items-center justify-center font-display font-black text-xs text-black uppercase">
                        {post.username[0]}
                      </div>
                      <div>
                        <div className="text-xs font-bold text-zinc-100 flex items-center space-x-1.5">
                          <span>{post.username}</span>
                          {post.isLive && (
                            <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500 animate-ping" />
                          )}
                        </div>
                        <div className="text-[10px] text-zinc-500 font-mono">{post.handle}</div>
                      </div>
                    </div>
                    
                    <span className={`font-mono text-[9px] px-1.5 py-0.5 rounded-none font-bold ${
                      post.isLive ? 'bg-red-500/25 text-red-400' : 'bg-white/5 text-zinc-500'
                    }`}>
                      {post.timestamp}
                    </span>
                  </div>

                  <p className="text-zinc-300 text-xs leading-relaxed font-sans">{post.content}</p>
                </div>
              ))}
            </div>
            
            {/* Mock phone navigation indicator */}
            <div className="w-20 h-1 bg-white/20 mx-auto mt-2 shrink-0" />
          </div>
        </section>

        {/* Quick Intel Bento Grid - 7 Cols */}
        <section className="lg:col-span-7 space-y-4" id="intel-bento-section">
          <div className="flex items-center space-x-2">
            <HelpCircle className="h-5 w-5 text-cyan-400" />
            <h2 className="text-sm font-display font-black text-white tracking-widest uppercase">Essential Game Intelligence</h2>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {quickFacts.map((fact, idx) => (
              <div 
                key={idx}
                className="rounded-none border border-white/10 bg-black p-5 hover:border-pink-500/50 transition-colors flex flex-col md:flex-row gap-4 items-start md:items-center relative overflow-hidden group text-left"
                id={`intel-card-${idx}`}
              >
                {/* Visual Accent */}
                <div className="h-10 w-10 shrink-0 bg-white/5 border border-white/10 flex items-center justify-center text-pink-500 font-display font-black text-sm group-hover:bg-pink-500 group-hover:text-black transition-colors">
                  <span>{idx + 1}</span>
                </div>

                <div className="space-y-1">
                  <span className="text-zinc-500 text-[9px] font-mono uppercase tracking-widest font-bold block">{fact.label}</span>
                  <h3 className="text-white text-base font-display font-bold tracking-tight">{fact.value}</h3>
                  <p className="text-zinc-400 text-xs leading-relaxed font-sans">{fact.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

      </div>

      {/* 9. UPGRADED BETTER CTA SECTION */}
      <section className="relative overflow-hidden bg-[#050505] border border-white/10 p-8 sm:p-12 text-center space-y-6" id="upgraded-cta-section">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-pink-500/10 via-transparent to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-orange-500/5 via-transparent to-transparent pointer-events-none" />
        <div className="absolute top-0 inset-x-0 h-[1px] bg-gradient-to-r from-transparent via-pink-500/40 to-transparent" />
        
        <div className="max-w-2xl mx-auto space-y-4">
          <div className="inline-flex items-center space-x-1.5 bg-orange-500/10 border border-orange-500/30 text-orange-400 px-3 py-1 text-[9px] font-mono font-black uppercase tracking-widest">
            <Zap className="h-3 w-3" />
            <span>Active Speculative Platform Radar</span>
          </div>
          
          <h2 className="text-3xl sm:text-5xl font-display font-black text-white uppercase tracking-tighter leading-tight">
            Dive Deep into the <br />
            <span className="bg-gradient-to-r from-pink-500 to-orange-400 bg-clip-text text-transparent">Vice City Database</span>
          </h2>
          
          <p className="text-zinc-400 text-sm font-sans max-w-lg mx-auto leading-relaxed">
            Our collective fact-checking matrix continuously updates every pixel of available trailers, patent records, and verified real-world location matchings.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-4 max-w-md mx-auto">
          <button 
            onClick={() => setView('database')}
            className="w-full sm:w-auto rounded-none bg-pink-600 hover:bg-pink-500 text-black font-display font-black text-xs uppercase tracking-widest px-8 py-4.5 transition-colors flex items-center justify-center space-x-2 shadow-[0_0_20px_rgba(236,72,153,0.15)]"
          >
            <span>Browse Asset DB</span>
            <ExternalLink className="h-4 w-4" />
          </button>
          
          <button 
            onClick={() => setView('map')}
            className="w-full sm:w-auto rounded-none bg-zinc-950 hover:bg-zinc-900 border border-white/10 hover:border-pink-500/30 text-white font-display font-black text-xs uppercase tracking-widest px-8 py-4.5 transition-colors flex items-center justify-center space-x-2"
          >
            <span>Interactive Speculative Map</span>
          </button>
        </div>
      </section>

      {/* 10. COMMUNITY HIGHLIGHTS SECTION (PRESERVED & STYLED) */}
      <section className="space-y-6 pt-6 border-t border-white/5" id="weekly-highlights-module">
        <div className="flex items-center space-x-2 text-left">
          <Sparkles className="h-5 w-5 text-pink-500" />
          <h2 className="text-sm font-display font-black text-white tracking-widest uppercase">Weekly Leonida Highlights</h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            {
              title: "Theorist of the Week",
              value: "@LeonidaMapper",
              desc: "Engineered a stunning 1:1 overlay of the Keys coastline utilizing real-world Florida geological surveys.",
              badge: "CONTRIBUTOR",
              color: "border-pink-500/20 text-pink-500",
            },
            {
              title: "Hottest Speculation",
              value: "AI Crowd Protocols",
              desc: "Deep analysis of Rockstar patent logs reveals a highly responsive dynamic heat system for beach crowds.",
              badge: "92% LIKELY",
              color: "border-cyan-500/20 text-cyan-400",
            },
            {
              title: "Top Community Asset",
              value: "Cheetah Classic",
              desc: "Confirmed spotting on Vice Neon Strip with real-time vector shader deformation physics.",
              badge: "VERIFIED",
              color: "border-emerald-500/20 text-emerald-400",
            },
            {
              title: "Mapping Progress",
              value: "94.2% Completeness",
              desc: "The collective coordinate database has mapped approximately 144sq km of simulated terrain.",
              badge: "94.2% CONSENSUS",
              color: "border-orange-500/20 text-orange-400",
            }
          ].map((item, idx) => (
            <div 
              key={idx} 
              className="bg-[#050505] border border-white/10 p-5 space-y-3 hover:border-pink-500/30 transition-colors relative text-left"
            >
              <div className="flex justify-between items-start">
                <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest block">{item.title}</span>
                <span className={`text-[8px] font-mono px-1.5 py-0.5 border ${item.color} uppercase font-black`}>
                  {item.badge}
                </span>
              </div>
              <h3 className="text-white text-base font-display font-black uppercase tracking-tight">{item.value}</h3>
              <p className="text-zinc-400 text-xs leading-relaxed font-sans">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* TELEMETRY SYSTEM BLOCK (Home View Extra Detail) */}
      <section className="bg-black/80 border border-white/5 p-4 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-zinc-600 font-mono">
        <div className="flex items-center space-x-2.5">
          <span className="h-2 w-2 rounded-none bg-emerald-500 animate-pulse" />
          <span>PORTAL ACTIVE STAGE: RADAR RECEPTIVITY COMPLIANT</span>
        </div>
        <div className="flex space-x-6">
          <span>LAT: 25.7617° N</span>
          <span>LNG: 80.1918° W</span>
          <span className="text-pink-500/80">COMMUNITY POWERED v2.6</span>
        </div>
      </section>

      {/* VIDEO POPUP STREAMING MODAL */}
      <AnimatePresence>
        {selectedVideoEmbedId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-4xl bg-zinc-950 border border-white/10 shadow-2xl overflow-hidden"
            >
              <button
                onClick={() => setSelectedVideoEmbedId(null)}
                className="absolute top-4 right-4 bg-black/80 border border-white/10 text-zinc-400 hover:text-white p-2 z-10 hover:border-pink-500/40"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="aspect-video w-full bg-black">
                <iframe
                  title="GTA VI Stream Feed"
                  className="w-full h-full"
                  src={`https://www.youtube.com/embed/${selectedVideoEmbedId}?autoplay=1`}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* IMAGE EASTER EGG LIGHTBOX */}
      <AnimatePresence>
        {selectedImageId && activeImageFrame && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-2xl bg-zinc-950 border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl text-left"
            >
              <button
                onClick={() => setSelectedImageId(null)}
                className="absolute top-4 right-4 bg-black border border-white/10 text-zinc-400 hover:text-white p-1.5 hover:border-pink-500/40"
              >
                <X className="h-5 w-5" />
              </button>

              <div className="space-y-4">
                <div>
                  <span className="text-orange-500 font-mono text-[9px] tracking-widest uppercase font-black block mb-1">
                    TRAILER TIMESTAMP SPECTRUM: {activeImageFrame.timestamp}
                  </span>
                  <h2 className="text-xl sm:text-2xl font-display font-black text-white uppercase tracking-tight">
                    {activeImageFrame.title}
                  </h2>
                </div>

                <div className="aspect-video w-full bg-cover bg-center border border-white/10" style={{ backgroundImage: `url('${activeImageFrame.imageUrl}')` }} />

                <div className="space-y-2">
                  <p className="text-zinc-400 text-xs sm:text-sm font-sans leading-relaxed">
                    {activeImageFrame.description}
                  </p>
                </div>

                {/* Easter Eggs list */}
                {activeImageFrame.easterEggs && activeImageFrame.easterEggs.length > 0 && (
                  <div className="border-t border-white/5 pt-4 space-y-2">
                    <span className="text-[10px] font-mono text-pink-500 uppercase font-black block">
                      ★★ Analyzed Easter Eggs & Telemetries ★★
                    </span>
                    <ul className="space-y-1.5">
                      {activeImageFrame.easterEggs.map((egg, idx) => (
                        <li key={idx} className="text-xs text-zinc-300 font-sans flex items-start space-x-2">
                          <Check className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{egg}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* PRE-ORDER WISH-LIST PREFERENCES MODAL */}
      <AnimatePresence>
        {isPreorderOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md" id="home-preorder-modal-container">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-lg bg-zinc-950 border border-white/10 p-6 sm:p-8 space-y-6 shadow-2xl text-left"
              id="home-preorder-modal-card"
            >
              <button
                onClick={() => setIsPreorderOpen(false)}
                className="absolute top-4 right-4 text-zinc-400 hover:text-white p-1"
                id="home-preorder-close-btn"
              >
                <X className="h-5 w-5" />
              </button>

              {!preorderSuccess ? (
                <div className="space-y-6">
                  <div>
                    <span className="text-pink-500 font-mono text-[9px] tracking-widest uppercase font-black block mb-1">
                      OFFICIAL PRE-ORDER WISH-LIST
                    </span>
                    <h2 className="text-2xl font-display font-black text-white uppercase tracking-tight">
                      Grand Theft Auto VI
                    </h2>
                    <p className="text-zinc-400 text-xs mt-1 font-sans">
                      Target Launch: Fall 2025 (Official Window). Select your preferences to register your community wishlist and notification alert.
                    </p>
                  </div>

                  {/* Platform Selection */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">
                      1. Select Target Platform
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { id: 'ps5', label: 'PlayStation 5' },
                        { id: 'xbox', label: 'Xbox Series X|S' }
                      ].map(plat => (
                        <button
                          key={plat.id}
                          onClick={() => setPreorderPlatform(plat.id as any)}
                          className={`p-3 text-xs font-mono font-black uppercase border text-center transition-all ${
                            preorderPlatform === plat.id
                              ? 'border-pink-500 bg-pink-500/10 text-pink-500'
                              : 'border-white/5 bg-black text-zinc-400 hover:text-white hover:bg-white/5'
                          }`}
                        >
                          {plat.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Edition Selection */}
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono text-zinc-500 uppercase tracking-wider block">
                      2. Select Edition Preference
                    </label>
                    <div className="space-y-2">
                      {[
                        { id: 'standard', label: 'Standard Edition', price: '$69.99', desc: 'Full base game and standard Vice City pre-order digital pack.' },
                        { id: 'deluxe', label: 'Deluxe Digital Bundle', price: '$89.99', desc: 'Base game, Vice City weapon skins, and 3-day early story mode access.' },
                        { id: 'collector', label: 'Leonida Collector\'s Kit', price: '$149.99', desc: 'Deluxe bundle, premium digital soundtrack, and dynamic steelbook physical ticket.' }
                      ].map(edit => (
                        <button
                          key={edit.id}
                          onClick={() => setPreorderEdition(edit.id as any)}
                          className={`w-full p-3.5 text-left border transition-all flex justify-between items-start gap-4 ${
                            preorderEdition === edit.id
                              ? 'border-pink-500 bg-pink-500/10 text-white'
                              : 'border-white/5 bg-black text-zinc-400 hover:text-white'
                          }`}
                        >
                          <div className="space-y-1">
                            <span className="text-xs font-mono font-black uppercase block">{edit.label}</span>
                            <span className="text-[10px] text-zinc-500 font-sans block leading-snug">{edit.desc}</span>
                          </div>
                          <span className="font-mono text-xs font-bold text-pink-500 shrink-0">{edit.price}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Action Button */}
                  <button
                    onClick={() => setPreorderSuccess(true)}
                    className="w-full bg-gradient-to-r from-pink-500 to-orange-400 text-black font-display font-black text-xs uppercase tracking-widest py-4 hover:opacity-90 transition-opacity animate-pulse"
                    id="home-preorder-submit-btn"
                  >
                    Confirm Wishlist Selection
                  </button>
                </div>
              ) : (
                <div className="space-y-6 text-center py-4">
                  <div className="w-12 h-12 bg-pink-500 text-black mx-auto flex items-center justify-center font-display font-black text-xl">
                    ✓
                  </div>
                  <div className="space-y-2">
                    <span className="text-pink-500 font-mono text-[9px] tracking-widest uppercase font-black block">
                      WISH-LIST REGISTRATION COMPLETE
                    </span>
                    <h3 className="text-xl sm:text-2xl font-display font-black text-white uppercase tracking-tight">
                      Alert Preferences Saved!
                    </h3>
                    <p className="text-zinc-400 text-xs font-sans max-w-sm mx-auto">
                      Your preferences for the <strong className="text-white">{preorderEdition.toUpperCase()} EDITION</strong> on <strong className="text-white">{preorderPlatform.toUpperCase()}</strong> have been registered. You will be notified the instant official pre-orders open.
                    </p>
                  </div>

                  {/* Mock Ticket */}
                  <div className="border border-dashed border-white/20 p-4 bg-zinc-900 font-mono text-left space-y-3 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-1.5 bg-gradient-to-r from-pink-500 to-orange-400 left-0" />
                    <div className="flex justify-between text-[10px] text-zinc-500">
                      <span>ALERT_TYPE: LAUNCH_NOTIFICATION</span>
                      <span>SEC_KEY: #VI-{Math.floor(100000 + Math.random() * 900000)}</span>
                    </div>
                    <div className="border-t border-white/5 pt-2 flex justify-between items-center">
                      <div>
                        <span className="text-[9px] text-zinc-500 block">DESTINATION</span>
                        <span className="text-white text-xs font-bold font-display tracking-wide">STATE OF LEONIDA</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] text-zinc-500 block">OFFICIAL TARGET</span>
                        <span className="text-pink-400 text-xs font-bold">FALL 2025</span>
                      </div>
                    </div>
                    <div className="border-t border-dashed border-white/10 pt-2.5 text-center">
                      <span className="text-[8px] text-zinc-600 block tracking-widest select-none">
                        ||| ||| | ||| |||| | ||| | ||||| | |||
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={() => setIsPreorderOpen(false)}
                    className="w-full bg-zinc-900 hover:bg-zinc-800 border border-white/10 text-white font-mono text-xs uppercase tracking-wider py-3"
                    id="home-preorder-finish-btn"
                  >
                    Return to Hub Overview
                  </button>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
