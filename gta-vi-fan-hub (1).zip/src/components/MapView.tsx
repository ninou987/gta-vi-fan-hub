import React, { useState, useMemo, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Map as MapIcon, Compass, Navigation, Eye, AlertTriangle, ShieldCheck, 
  Waves, Trees, Building, MapPin, Search, Filter, Plus, X, Trash2, 
  Camera, CheckSquare, Square, Home, Info, Crosshair, ArrowRight, Sparkles
} from 'lucide-react';
import { mapPointsData } from '../data/gtaData';
import { MapPoint } from '../types';
import OptimizedImage from './OptimizedImage';

// Extend MapPoint with customizable items or just keep the core structure
interface EnhancedMapPoint extends MapPoint {
  touristTraffic?: number; // 0-100
  policePresence?: number; // 0-100
  underworldActivity?: number; // 0-100
  isCustom?: boolean;
}

export default function MapView() {
  // Map points state (initialized with pre-seed data)
  const [points, setPoints] = useState<EnhancedMapPoint[]>(() => {
    return mapPointsData.map(p => {
      // Seed details dynamically for the default locations to enrich the dossier
      let tourist = 50;
      let police = 50;
      let underworld = 50;

      if (p.category === 'coastal') {
        tourist = 92; police = 35; underworld = 40;
      } else if (p.category === 'urban') {
        tourist = 80; police = 85; underworld = 75;
      } else if (p.category === 'nature') {
        tourist = 15; police = 15; underworld = 60;
      } else if (p.category === 'suburban') {
        tourist = 45; police = 55; underworld = 80;
      }

      return {
        ...p,
        touristTraffic: tourist,
        policePresence: police,
        underworldActivity: underworld,
        isCustom: false
      };
    });
  });

  // Selected & Hover states
  const [selectedPointId, setSelectedPointId] = useState<string>('vice-beach');
  const [hoveredPointId, setHoveredPointId] = useState<string | null>(null);

  // Search & Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedHazard, setSelectedHazard] = useState<string>('all');

  // Interactive Custom Point Plotting state
  const [isPlottingMode, setIsPlottingMode] = useState(false);
  const [plottedCoords, setPlottedCoords] = useState<{ x: number; y: number } | null>(null);
  const [newPointName, setNewPointName] = useState('');
  const [newPointCategory, setNewPointCategory] = useState<'urban' | 'suburban' | 'nature' | 'coastal'>('urban');
  const [newPointHazard, setNewPointHazard] = useState<'Low' | 'Medium' | 'High' | 'Extreme'>('Medium');
  const [newPointDesc, setNewPointDesc] = useState('');
  const [newPointCounterpart, setNewPointCounterpart] = useState('');
  const [newPointSights, setNewPointSights] = useState('');
  const [newPointActivities, setNewPointActivities] = useState('');

  // Checklist for Interactive scouting (saved in state per point)
  const [scoutedStatus, setScoutedStatus] = useState<Record<string, string[]>>({
    'vice-beach': ['Beach Promenade'],
    'port-gellhorn': ['Gellhorn Raceways']
  });

  // Mobile navigation tabs: 'map' or 'list' or 'plotting'
  const [activeMobileTab, setActiveMobileTab] = useState<'map' | 'dossier' | 'list'>('map');

  // Ref for absolute coordinate calculations
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const [cursorCoords, setCursorCoords] = useState<{ x: number; y: number } | null>(null);

  const selectedPoint = useMemo(() => {
    return points.find((p) => p.id === selectedPointId) || points[0];
  }, [points, selectedPointId]);

  // Handle click on map container to register a potential plotted point
  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mapContainerRef.current) return;
    const rect = mapContainerRef.current.getBoundingClientRect();
    const x = Math.min(100, Math.max(0, ((e.clientX - rect.left) / rect.width) * 100));
    const y = Math.min(100, Math.max(0, ((e.clientY - rect.top) / rect.height) * 100));
    
    setPlottedCoords({ x: Math.round(x * 10) / 10, y: Math.round(y * 10) / 10 });
    setIsPlottingMode(true);
    // Auto shift to plotting view on mobile so they can see form
    setActiveMobileTab('map');
  };

  // Move tracking for general crosshairs
  const handleMapMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!mapContainerRef.current) return;
    const rect = mapContainerRef.current.getBoundingClientRect();
    const x = Math.min(100, Math.max(0, ((e.clientX - rect.left) / rect.width) * 100));
    const y = Math.min(100, Math.max(0, ((e.clientY - rect.top) / rect.height) * 100));
    setCursorCoords({ x: Math.round(x), y: Math.round(y) });
  };

  const handleMapMouseLeave = () => {
    setCursorCoords(null);
  };

  // Create customized point
  const handleAddCustomPoint = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPointName.trim() || !plottedCoords) return;

    const customId = `custom-${Date.now()}`;
    const newPoint: EnhancedMapPoint = {
      id: customId,
      name: newPointName,
      category: newPointCategory,
      coordinates: plottedCoords,
      description: newPointDesc || 'User documented high-value speculative region.',
      realLifeCounterpart: newPointCounterpart || 'Unknown Leonida Boundary',
      keySights: newPointSights ? newPointSights.split(',').map(s => s.trim()) : ['Custom Coordinate Hub'],
      speculatedActivities: newPointActivities ? newPointActivities.split(',').map(s => s.trim()) : ['Underworld surveillance'],
      screenshotDescription: 'Custom satellite waypoint added via local tactical node.',
      hazardLevel: newPointHazard,
      touristTraffic: Math.floor(Math.random() * 50) + 10,
      policePresence: Math.floor(Math.random() * 60) + 20,
      underworldActivity: Math.floor(Math.random() * 70) + 30,
      isCustom: true
    };

    setPoints(prev => [...prev, newPoint]);
    setSelectedPointId(customId);
    
    // Reset plotting form
    setNewPointName('');
    setNewPointDesc('');
    setNewPointCounterpart('');
    setNewPointSights('');
    setNewPointActivities('');
    setIsPlottingMode(false);
    setPlottedCoords(null);
  };

  // Delete customized point
  const handleDeletePoint = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setPoints(prev => prev.filter(p => p.id !== id));
    if (selectedPointId === id) {
      setSelectedPointId('vice-beach');
    }
  };

  // Filter and search logic
  const filteredPoints = useMemo(() => {
    return points.filter((p) => {
      const matchesSearch = 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.realLifeCounterpart.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.keySights.some(sight => sight.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
      const matchesHazard = selectedHazard === 'all' || p.hazardLevel === selectedHazard;

      return matchesSearch && matchesCategory && matchesHazard;
    });
  }, [points, searchQuery, selectedCategory, selectedHazard]);

  // Handle checking/unchecking sights
  const toggleSoughtSight = (pointId: string, sight: string) => {
    setScoutedStatus(prev => {
      const currentList = prev[pointId] || [];
      const updatedList = currentList.includes(sight)
        ? currentList.filter(s => s !== sight)
        : [...currentList, sight];
      return {
        ...prev,
        [pointId]: updatedList
      };
    });
  };

  // Styles helpers
  const getHazardStyles = (level: string) => {
    switch (level) {
      case 'Low': return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/20';
      case 'Medium': return 'bg-amber-500/15 text-amber-400 border-amber-500/20';
      case 'High': return 'bg-orange-500/15 text-orange-400 border-orange-500/20';
      case 'Extreme': return 'bg-red-500/20 text-red-500 border-red-500/30';
      default: return 'bg-zinc-800 text-zinc-400';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'coastal': return Waves;
      case 'nature': return Trees;
      case 'urban': return Building;
      case 'suburban': return Home;
      default: return Compass;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'coastal': return 'text-cyan-400 border-cyan-400/20 bg-cyan-400/5';
      case 'nature': return 'text-emerald-400 border-emerald-400/20 bg-emerald-400/5';
      case 'urban': return 'text-pink-500 border-pink-500/20 bg-pink-500/5';
      case 'suburban': return 'text-amber-400 border-amber-400/20 bg-amber-400/5';
      default: return 'text-zinc-400 border-zinc-400/20 bg-zinc-400/5';
    }
  };

  // Get static beautiful cover photos matching the region
  const getCoverImage = (id: string) => {
    switch (id) {
      case 'vice-beach': return 'https://images.unsplash.com/photo-1519046904884-53103b34b206?auto=format&fit=crop&q=80&w=600';
      case 'port-gellhorn': return 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&q=80&w=600';
      case 'leonida-grasslands': return 'https://images.unsplash.com/photo-1504370805625-d32c54b16100?auto=format&fit=crop&q=80&w=600';
      case 'the-keys': return 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=600';
      case 'vice-downtown': return 'https://images.unsplash.com/photo-1506970135314-04a8e5318182?auto=format&fit=crop&q=80&w=600';
      case 'kelly-county': return 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&q=80&w=600';
      default: return 'https://images.unsplash.com/photo-1518005020951-eccb494ad742?auto=format&fit=crop&q=80&w=600';
    }
  };

  return (
    <div className="space-y-6 pb-12 text-left max-w-7xl mx-auto" id="map-view-root">
      
      {/* Header section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 border-b border-white/5 pb-4">
        <div>
          <span className="text-pink-500 font-mono text-[10px] font-black tracking-widest uppercase block mb-1">
            GPS SPECTRAL TRACKING • LIVE INTERACTIVE RADAR
          </span>
          <h1 className="text-3xl sm:text-5xl font-display font-black text-white tracking-tighter uppercase leading-none">
            Leonida Tactical Radar
          </h1>
          <p className="text-zinc-400 text-sm mt-2 max-w-3xl font-sans">
            Explore verified landmarks, speculate coordinate zones, filter district hazards, and deploy custom tactical pins directly on the live telemetry board.
          </p>
        </div>

        {/* Live coordinate tracking summary */}
        <div className="hidden sm:flex bg-black/90 border border-white/10 px-4 py-2 text-xs font-mono text-zinc-400 space-x-6 shrink-0">
          <div>
            <span className="text-[9px] text-zinc-600 block uppercase font-bold">RADAR INTEL</span>
            <span className="text-white font-bold">{points.length} Districts</span>
          </div>
          <div>
            <span className="text-[9px] text-zinc-600 block uppercase font-bold">CUSTOM WAYPOINTS</span>
            <span className="text-pink-500 font-black">{points.filter(p => p.isCustom).length} plotted</span>
          </div>
          <div>
            <span className="text-[9px] text-zinc-600 block uppercase font-bold">GRID STATUS</span>
            <span className="text-emerald-400 font-bold uppercase">Online (100%)</span>
          </div>
        </div>
      </div>

      {/* SEARCH AND FILTERS TOOLBAR */}
      <div className="bg-black/50 border border-white/10 p-4 space-y-3 sm:space-y-0 sm:flex sm:items-center sm:justify-between gap-4" id="map-filters-toolbar">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-zinc-500" />
          <input
            type="text"
            placeholder="Search landmarks, counties, counterparts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-950 border border-white/10 pl-9 pr-4 py-2 text-xs font-mono text-white placeholder-zinc-500 focus:outline-none focus:border-pink-500 rounded-none transition-colors"
          />
          {searchQuery && (
            <button 
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-2.5 hover:text-white text-zinc-500"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 font-mono text-xs">
          {/* Category Filter */}
          <div className="flex items-center space-x-1.5">
            <Filter className="h-3.5 w-3.5 text-zinc-500" />
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="bg-zinc-950 border border-white/10 text-zinc-300 py-1.5 px-2.5 focus:outline-none focus:border-pink-500 text-xs"
            >
              <option value="all">All Sectors</option>
              <option value="coastal">Coastal Nodes</option>
              <option value="nature">Nature Zones</option>
              <option value="urban">Urban Centers</option>
              <option value="suburban">Suburban Blocks</option>
            </select>
          </div>

          {/* Hazard Filter */}
          <div className="flex items-center space-x-1.5">
            <AlertTriangle className="h-3.5 w-3.5 text-zinc-500" />
            <select
              value={selectedHazard}
              onChange={(e) => setSelectedHazard(e.target.value)}
              className="bg-zinc-950 border border-white/10 text-zinc-300 py-1.5 px-2.5 focus:outline-none focus:border-pink-500 text-xs"
            >
              <option value="all">All Hazard Levels</option>
              <option value="Low">Low Threat</option>
              <option value="Medium">Medium Threat</option>
              <option value="High">High Threat</option>
              <option value="Extreme">Extreme Threat</option>
            </select>
          </div>
        </div>
      </div>

      {/* MOBILE TAB CONTROLLER */}
      <div className="flex sm:hidden border-b border-white/10 font-mono text-xs">
        <button
          onClick={() => setActiveMobileTab('map')}
          className={`flex-1 py-3 text-center border-b-2 font-bold uppercase tracking-wider ${activeMobileTab === 'map' ? 'border-pink-500 text-pink-500' : 'border-transparent text-zinc-500'}`}
        >
          Radar Map
        </button>
        <button
          onClick={() => setActiveMobileTab('dossier')}
          className={`flex-1 py-3 text-center border-b-2 font-bold uppercase tracking-wider ${activeMobileTab === 'dossier' ? 'border-pink-500 text-pink-500' : 'border-transparent text-zinc-500'}`}
        >
          Dossier ({selectedPoint.name})
        </button>
        <button
          onClick={() => setActiveMobileTab('list')}
          className={`flex-1 py-3 text-center border-b-2 font-bold uppercase tracking-wider ${activeMobileTab === 'list' ? 'border-pink-500 text-pink-500' : 'border-transparent text-zinc-500'}`}
        >
          Sectors ({filteredPoints.length})
        </button>
      </div>

      {/* MAIN LAYOUT */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: Map View + Custom plotting (7 Columns on desktop) */}
        <div className={`lg:col-span-7 space-y-4 ${activeMobileTab !== 'map' ? 'hidden sm:block' : ''}`}>
          
          <div 
            className="relative aspect-[4/3] w-full border border-white/10 bg-black overflow-hidden shadow-2xl p-1 cursor-crosshair select-none"
            id="radar-map-board"
            ref={mapContainerRef}
            onClick={handleMapClick}
            onMouseMove={handleMapMouseMove}
            onMouseLeave={handleMapMouseLeave}
          >
            
            {/* Radar Signal Strobe overlay */}
            <div className="absolute inset-0 bg-black bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-zinc-950 via-black to-black pointer-events-none" />

            {/* Simulated Geographic SVG Contours */}
            <svg className="absolute inset-0 w-full h-full opacity-30 pointer-events-none" viewBox="0 0 100 100" preserveAspectRatio="none">
              {/* Mainland Outline */}
              <path d="M 10,20 Q 30,10 50,25 T 90,20 T 95,45 Q 80,70 65,85 T 30,95 Q 15,80 5,60 T 10,20 Z" fill="none" stroke="#3f3f46" strokeWidth="0.5" />
              {/* Wetlands swamp network */}
              <path d="M 28,45 Q 35,35 45,50 T 65,60 L 55,75 Z" fill="#022c22" opacity="0.3" stroke="#059669" strokeWidth="0.1" />
              {/* Lakes / Waterways */}
              <circle cx="55" cy="40" r="6" fill="#1e1b4b" opacity="0.4" />
              <path d="M 12,50 Q 30,62 48,55" stroke="#1d4ed8" strokeWidth="0.4" fill="none" opacity="0.4" />
              {/* Keys Island Scatterings */}
              <circle cx="15" cy="80" r="3" fill="#0284c7" opacity="0.4" />
              <circle cx="28" cy="84" r="2.5" fill="#0284c7" opacity="0.4" />
              <circle cx="42" cy="88" r="4" fill="#0284c7" opacity="0.4" />
              <circle cx="58" cy="86" r="3.5" fill="#0284c7" opacity="0.4" />
            </svg>

            {/* Coordinates Grid lines */}
            <div className="absolute inset-0 grid grid-cols-10 grid-rows-10 opacity-10 pointer-events-none border-t border-l border-zinc-700">
              {Array.from({ length: 100 }).map((_, gridIdx) => (
                <div key={gridIdx} className="border-r border-b border-zinc-800 text-[6px] text-zinc-600 p-0.5 select-none">
                  {gridIdx % 10 === 0 ? `Y0${Math.floor(gridIdx/10)}` : ''}
                </div>
              ))}
            </div>

            {/* Interactive Cursor Target Crosshair Line indicators */}
            {cursorCoords && (
              <>
                <div className="absolute top-0 bottom-0 border-l border-pink-500/15 pointer-events-none" style={{ left: `${cursorCoords.x}%` }} />
                <div className="absolute left-0 right-0 border-t border-pink-500/15 pointer-events-none" style={{ top: `${cursorCoords.y}%` }} />
                <div className="absolute bottom-2 left-2 bg-black/80 border border-white/10 px-2 py-0.5 font-mono text-[9px] text-pink-400 pointer-events-none">
                  X: {cursorCoords.x}% | Y: {cursorCoords.y}%
                </div>
              </>
            )}

            {/* Hover lasers for selected and hovered point */}
            {(hoveredPointId || selectedPointId) && (
              (() => {
                const targetPoint = points.find(p => p.id === (hoveredPointId || selectedPointId));
                if (!targetPoint) return null;
                return (
                  <>
                    <div className="absolute top-0 bottom-0 border-l border-pink-500/30 border-dashed pointer-events-none" style={{ left: `${targetPoint.coordinates.x}%` }} />
                    <div className="absolute left-0 right-0 border-t border-pink-500/30 border-dashed pointer-events-none" style={{ top: `${targetPoint.coordinates.y}%` }} />
                  </>
                );
              })()
            )}

            {/* Sweep radar hand */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              <motion.div 
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 15, ease: 'linear' }}
                className="absolute w-[200%] h-[200%] top-[-50%] left-[-50%] origin-center bg-gradient-to-tr from-pink-500/0 via-pink-500/0 to-pink-500/5"
              />
            </div>

            {/* PLOTTED WAYPOINTS RENDER */}
            {filteredPoints.map((point) => {
              const isSelected = selectedPointId === point.id;
              const isHovered = hoveredPointId === point.id;
              const Icon = getCategoryIcon(point.category);
              
              return (
                <button
                  key={point.id}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedPointId(point.id);
                  }}
                  onMouseEnter={() => setHoveredPointId(point.id)}
                  onMouseLeave={() => setHoveredPointId(null)}
                  style={{ left: `${point.coordinates.x}%`, top: `${point.coordinates.y}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 z-20 focus:outline-none group"
                  id={`map-node-${point.id}`}
                >
                  <div className="relative flex items-center justify-center">
                    
                    {/* Ring glow */}
                    {isSelected && (
                      <motion.span 
                        layoutId="active-marker-glow"
                        className="absolute h-10 w-10 bg-pink-500/20 border border-pink-500/40"
                        animate={{ scale: [1, 1.3, 1] }}
                        transition={{ repeat: Infinity, duration: 2 }}
                      />
                    )}

                    {/* Simple point marker */}
                    <div className={`p-2 shadow-2xl border transition-all ${
                      isSelected 
                        ? 'bg-pink-600 border-black text-black scale-110 z-30' 
                        : isHovered
                          ? 'bg-zinc-850 border-pink-500 text-pink-400 scale-105 z-25'
                          : 'bg-[#09090b] border-zinc-700 text-zinc-300'
                    }`}>
                      <Icon className="h-3.5 w-3.5" />
                    </div>

                    {/* Popover overlay label */}
                    <span className={`absolute top-7 whitespace-nowrap bg-black/90 border text-[9px] font-mono px-2 py-0.5 shadow-lg transition-all ${
                      isSelected 
                        ? 'opacity-100 text-pink-500 scale-100 border-pink-500/30' 
                        : isHovered 
                          ? 'opacity-100 scale-100 text-zinc-200 border-white/20'
                          : 'opacity-0 scale-95 pointer-events-none'
                    }`}>
                      {point.name} {point.isCustom && '(CUSTOM)'}
                    </span>
                  </div>
                </button>
              );
            })}

            {/* Dynamic Plotted coordinates marker that has not yet been submitted */}
            {plottedCoords && (
              <div 
                className="absolute -translate-x-1/2 -translate-y-1/2 z-40 bg-pink-500 border border-black p-1.5 animate-bounce"
                style={{ left: `${plottedCoords.x}%`, top: `${plottedCoords.y}%` }}
              >
                <Crosshair className="h-4.5 w-4.5 text-black" />
              </div>
            )}

            {/* Instruction bar overlay inside radar map */}
            <div className="absolute top-2 right-2 bg-black/95 border border-white/10 px-3 py-1.5 font-mono text-[9px] text-zinc-500 select-none space-y-0.5">
              <span className="text-white font-bold block">TACTICAL CONTROLS</span>
              <span>Click anywhere on radar map to drop a custom pin.</span>
            </div>

          </div>

          {/* Quick instructions / Custom Plotting form if active */}
          <AnimatePresence mode="wait">
            {isPlottingMode && plottedCoords && (
              <motion.form
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                onSubmit={handleAddCustomPoint}
                className="bg-zinc-950 border border-white/10 p-5 space-y-4 text-left font-mono"
                id="custom-point-form"
              >
                <div className="flex justify-between items-center border-b border-white/5 pb-2">
                  <div className="flex items-center space-x-2">
                    <Plus className="h-4.5 w-4.5 text-pink-500" />
                    <span className="text-xs text-white uppercase font-black">Deploy Custom Coordinate Waypoint</span>
                  </div>
                  <button 
                    type="button"
                    onClick={() => {
                      setIsPlottingMode(false);
                      setPlottedCoords(null);
                    }}
                    className="text-zinc-500 hover:text-white"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  
                  {/* Name */}
                  <div className="space-y-1">
                    <label className="text-[10px] text-zinc-500 uppercase block font-bold">Waypoint Title *</label>
                    <input 
                      type="text"
                      placeholder="e.g. Starfish Island Hideout"
                      required
                      value={newPointName}
                      onChange={(e) => setNewPointName(e.target.value)}
                      className="w-full bg-black border border-white/10 px-3 py-2 text-zinc-300 focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  {/* Real counterpart */}
                  <div className="space-y-1">
                    <label className="text-[10px] text-zinc-500 uppercase block font-bold">Real Life Florida counterpart</label>
                    <input 
                      type="text"
                      placeholder="e.g. Star Island Miami"
                      value={newPointCounterpart}
                      onChange={(e) => setNewPointCounterpart(e.target.value)}
                      className="w-full bg-black border border-white/10 px-3 py-2 text-zinc-300 focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  {/* Category */}
                  <div className="space-y-1">
                    <label className="text-[10px] text-zinc-500 uppercase block font-bold">Sector Category</label>
                    <select
                      value={newPointCategory}
                      onChange={(e) => setNewPointCategory(e.target.value as any)}
                      className="w-full bg-black border border-white/10 px-3 py-2 text-zinc-300 focus:outline-none focus:border-pink-500"
                    >
                      <option value="urban">Urban Node</option>
                      <option value="suburban">Suburban Block</option>
                      <option value="nature">Nature / Swamps</option>
                      <option value="coastal">Coastal Shoreline</option>
                    </select>
                  </div>

                  {/* Hazard Level */}
                  <div className="space-y-1">
                    <label className="text-[10px] text-zinc-500 uppercase block font-bold">Threat Hazard Rating</label>
                    <select
                      value={newPointHazard}
                      onChange={(e) => setNewPointHazard(e.target.value as any)}
                      className="w-full bg-black border border-white/10 px-3 py-2 text-zinc-300 focus:outline-none focus:border-pink-500"
                    >
                      <option value="Low">Low Threat</option>
                      <option value="Medium">Medium Threat</option>
                      <option value="High">High Threat</option>
                      <option value="Extreme">Extreme Threat</option>
                    </select>
                  </div>

                  {/* Coordinates locked */}
                  <div className="sm:col-span-2 bg-black/40 border border-white/5 p-2 text-[10px] text-zinc-400 flex justify-between">
                    <span>LOCKED COORDINATES:</span>
                    <span className="text-pink-500 font-bold">X: {plottedCoords.x}% | Y: {plottedCoords.y}%</span>
                  </div>

                  {/* Description */}
                  <div className="sm:col-span-2 space-y-1">
                    <label className="text-[10px] text-zinc-500 uppercase block font-bold">Speculative Intelligence Overview</label>
                    <textarea 
                      placeholder="Input speculative findings or trailer sightings matching this location..."
                      rows={2}
                      value={newPointDesc}
                      onChange={(e) => setNewPointDesc(e.target.value)}
                      className="w-full bg-black border border-white/10 p-3 text-zinc-300 focus:outline-none focus:border-pink-500 resize-none font-sans"
                    />
                  </div>

                  {/* Sights */}
                  <div className="space-y-1">
                    <label className="text-[10px] text-zinc-500 uppercase block font-bold">Landmarks (Comma Separated)</label>
                    <input 
                      type="text"
                      placeholder="e.g. Shopping Mall, Gas Station"
                      value={newPointSights}
                      onChange={(e) => setNewPointSights(e.target.value)}
                      className="w-full bg-black border border-white/10 px-3 py-2 text-zinc-300 focus:outline-none focus:border-pink-500"
                    />
                  </div>

                  {/* Activities */}
                  <div className="space-y-1">
                    <label className="text-[10px] text-zinc-500 uppercase block font-bold">Crime Activities (Comma Separated)</label>
                    <input 
                      type="text"
                      placeholder="e.g. Heists, Car thefts"
                      value={newPointActivities}
                      onChange={(e) => setNewPointActivities(e.target.value)}
                      className="w-full bg-black border border-white/10 px-3 py-2 text-zinc-300 focus:outline-none focus:border-pink-500"
                    />
                  </div>

                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => {
                      setIsPlottingMode(false);
                      setPlottedCoords(null);
                    }}
                    className="px-4 py-2 border border-white/10 hover:bg-white/5 text-zinc-400 hover:text-white transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-pink-600 hover:bg-pink-500 text-black font-bold uppercase transition-colors"
                  >
                    Deploy Pin
                  </button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>

          {/* Quick swap index list of matching locations */}
          <div className="hidden sm:block space-y-2">
            <span className="text-[10px] font-mono text-zinc-500 uppercase block font-bold">Tactical Hotspots (Quick Navigation)</span>
            <div className="flex flex-wrap gap-1.5" id="map-quick-switches">
              {filteredPoints.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedPointId(p.id)}
                  onMouseEnter={() => setHoveredPointId(p.id)}
                  onMouseLeave={() => setHoveredPointId(null)}
                  className={`text-xs px-3 py-1.5 border font-mono tracking-wider transition-all relative ${
                    selectedPointId === p.id
                      ? 'bg-pink-600 border-pink-500 text-black font-black'
                      : 'bg-[#09090b] border-white/10 text-zinc-400 hover:border-pink-500/30 hover:text-white'
                  }`}
                >
                  <span className="flex items-center space-x-1">
                    <span>{p.name}</span>
                    {p.isCustom && <span className="text-[8px] bg-black/20 text-pink-500 px-1 font-bold">CUSTOM</span>}
                  </span>
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Interactive intelligence dossier (5 Columns on desktop) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* DOSSIER PANEL */}
          <div className={`${activeMobileTab === 'dossier' ? 'block' : 'hidden sm:block'}`}>
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedPoint.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="bg-[#09090b] border border-white/10 p-5 space-y-5 shadow-xl relative text-left"
                id={`map-intel-panel-${selectedPoint.id}`}
              >
                
                {/* Image header placeholder or map view reference */}
                <div className="relative aspect-video w-full bg-zinc-950 overflow-hidden border border-white/5">
                  <OptimizedImage 
                    src={getCoverImage(selectedPoint.id)} 
                    alt={selectedPoint.name}
                    aspectRatio="video"
                    className="opacity-80 hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent pointer-events-none" />
                  
                  {/* Status Overlay tag */}
                  <span className="absolute top-3 left-3 bg-black/90 border border-white/10 px-2 py-0.5 text-[8px] font-mono font-black text-pink-500 uppercase tracking-widest">
                    TELEMETRY FEED
                  </span>

                  {selectedPoint.isCustom && (
                    <button
                      onClick={(e) => handleDeletePoint(selectedPoint.id, e)}
                      className="absolute top-3 right-3 bg-red-600 hover:bg-red-500 p-1.5 text-black transition-colors"
                      title="Decommission custom waypoint"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>

                {/* Subheader */}
                <div className="flex justify-between items-center text-[10px] font-mono">
                  <span className={`px-2 py-0.5 border uppercase font-black tracking-widest ${getCategoryColor(selectedPoint.category)}`}>
                    {selectedPoint.category} Sector
                  </span>
                  
                  <span className={`px-2 py-0.5 border font-black uppercase ${getHazardStyles(selectedPoint.hazardLevel)}`}>
                    HAZARD: {selectedPoint.hazardLevel}
                  </span>
                </div>

                {/* Main Name */}
                <div className="space-y-1">
                  <h2 className="text-2xl font-display font-black text-white uppercase tracking-tight flex items-center space-x-1.5">
                    <MapPin className="h-5.5 w-5.5 text-pink-500 shrink-0" />
                    <span>{selectedPoint.name}</span>
                  </h2>
                  <div className="flex justify-between text-[10px] font-mono text-zinc-500 border-b border-white/5 pb-2">
                    <span>Counterpart: <strong className="text-white">{selectedPoint.realLifeCounterpart}</strong></span>
                    <span>X: {selectedPoint.coordinates.x}% | Y: {selectedPoint.coordinates.y}%</span>
                  </div>
                </div>

                {/* Overview Text */}
                <div className="space-y-1.5">
                  <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest block font-bold">Tactical Assessment</span>
                  <p className="text-zinc-300 text-xs leading-relaxed font-sans">
                    {selectedPoint.description}
                  </p>
                </div>

                {/* ADVANCED DOSSIER ENRICHMENT STATS (Bento-like indicators) */}
                <div className="grid grid-cols-3 gap-2 py-3 border-y border-white/5 font-mono text-[9px]">
                  <div className="bg-black/40 border border-white/5 p-2 space-y-1.5">
                    <span className="text-zinc-500 uppercase block font-bold">Tourist Activity</span>
                    <div className="flex items-center justify-between">
                      <span className="text-cyan-400 font-bold">{selectedPoint.touristTraffic || 50}%</span>
                      <div className="w-1.5 h-6 bg-zinc-950 p-0.5 border border-white/5 flex flex-col justify-end">
                        <div className="w-full bg-cyan-400" style={{ height: `${selectedPoint.touristTraffic || 50}%` }} />
                      </div>
                    </div>
                  </div>

                  <div className="bg-black/40 border border-white/5 p-2 space-y-1.5">
                    <span className="text-zinc-500 uppercase block font-bold">Law Enforcement</span>
                    <div className="flex items-center justify-between">
                      <span className="text-pink-500 font-bold">{selectedPoint.policePresence || 50}%</span>
                      <div className="w-1.5 h-6 bg-zinc-950 p-0.5 border border-white/5 flex flex-col justify-end">
                        <div className="w-full bg-pink-500" style={{ height: `${selectedPoint.policePresence || 50}%` }} />
                      </div>
                    </div>
                  </div>

                  <div className="bg-black/40 border border-white/5 p-2 space-y-1.5">
                    <span className="text-zinc-500 uppercase block font-bold">Underworld Risk</span>
                    <div className="flex items-center justify-between">
                      <span className="text-amber-500 font-bold">{selectedPoint.underworldActivity || 50}%</span>
                      <div className="w-1.5 h-6 bg-zinc-950 p-0.5 border border-white/5 flex flex-col justify-end">
                        <div className="w-full bg-amber-500" style={{ height: `${selectedPoint.underworldActivity || 50}%` }} />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Sights Interactive Checkoff */}
                <div className="space-y-2.5">
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest block font-bold">Recognized Landmarks</span>
                    <span className="text-[9px] font-mono text-pink-400 font-black">
                      Scouted: {((scoutedStatus[selectedPoint.id] || []).length)} / {selectedPoint.keySights.length}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {selectedPoint.keySights.map((sight, idx) => {
                      const isScouted = (scoutedStatus[selectedPoint.id] || []).includes(sight);
                      return (
                        <button 
                          key={idx} 
                          onClick={() => toggleSoughtSight(selectedPoint.id, sight)}
                          className={`flex items-center space-x-2 p-2.5 border text-left font-sans select-none transition-all ${
                            isScouted 
                              ? 'bg-pink-500/10 border-pink-500/30 text-white font-semibold' 
                              : 'bg-[#030303] border-white/5 text-zinc-400 hover:text-zinc-200 hover:border-white/10'
                          }`}
                        >
                          {isScouted ? (
                            <CheckSquare className="h-4 w-4 text-pink-500 shrink-0" />
                          ) : (
                            <Square className="h-4 w-4 text-zinc-700 shrink-0" />
                          )}
                          <span className="truncate">{sight}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Speculated Activities List */}
                <div className="space-y-2">
                  <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest block font-bold">Unvetted Speculative Activity</span>
                  <div className="space-y-1.5">
                    {selectedPoint.speculatedActivities.map((act, idx) => (
                      <div key={idx} className="bg-black/30 border border-white/5 p-2 text-xs text-zinc-300 font-mono flex items-start space-x-1.5">
                        <span className="text-pink-500">↳</span>
                        <span>{act}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Trailer 1 / Leak Proof verification block */}
                <div className="bg-[#030303] p-3 border border-white/10 space-y-1">
                  <div className="flex items-center space-x-1 text-[8px] text-cyan-400 font-mono font-black uppercase">
                    <Camera className="h-3.5 w-3.5" />
                    <span>TRAILER REFERENCE INDEX / SATELLITE FOOTAGE</span>
                  </div>
                  <p className="text-xs text-zinc-400 leading-normal italic font-sans">
                    "{selectedPoint.screenshotDescription}"
                  </p>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

          {/* SIDEBAR COORDINATES LIST (Visible on desktop or when list tab is active on mobile) */}
          <div className={`bg-black/40 border border-white/10 p-5 space-y-4 ${activeMobileTab === 'list' ? 'block' : 'hidden sm:block'}`}>
            <div className="flex justify-between items-center border-b border-white/5 pb-2">
              <span className="text-xs font-mono text-white uppercase font-black flex items-center gap-2">
                <Compass className="h-4 w-4 text-pink-500" />
                <span>Sector Indices ({filteredPoints.length})</span>
              </span>
              <span className="text-[10px] font-mono text-zinc-500">Active Scan</span>
            </div>

            <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
              {filteredPoints.length > 0 ? (
                filteredPoints.map((point) => {
                  const isSelected = selectedPointId === point.id;
                  const Icon = getCategoryIcon(point.category);
                  
                  return (
                    <div
                      key={point.id}
                      onClick={() => {
                        setSelectedPointId(point.id);
                        // On mobile, automatically swap to map view to focus on selection
                        setActiveMobileTab('map');
                      }}
                      onMouseEnter={() => setHoveredPointId(point.id)}
                      onMouseLeave={() => setHoveredPointId(null)}
                      className={`p-3 border text-left font-mono transition-all cursor-pointer flex justify-between items-center ${
                        isSelected 
                          ? 'bg-pink-600/10 border-pink-500 text-white' 
                          : 'bg-zinc-950/40 border-white/5 text-zinc-400 hover:border-pink-500/30 hover:text-white'
                      }`}
                    >
                      <div className="space-y-1 truncate pr-2">
                        <div className="flex items-center space-x-1.5">
                          <Icon className="h-3.5 w-3.5 text-zinc-500 shrink-0" />
                          <span className="text-xs font-black uppercase truncate text-white">{point.name}</span>
                          {point.isCustom && <span className="text-[7px] bg-pink-500/20 text-pink-400 px-1 font-bold">CUSTOM</span>}
                        </div>
                        <div className="text-[9px] text-zinc-500 truncate font-sans">
                          {point.realLifeCounterpart}
                        </div>
                      </div>

                      <div className="text-right flex flex-col items-end shrink-0">
                        <span className="text-[9px] font-bold text-pink-500">X:{point.coordinates.x}%</span>
                        <span className="text-[9px] font-bold text-zinc-500">Y:{point.coordinates.y}%</span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8 font-mono text-xs text-zinc-600">
                  No tactical targets located within search criteria.
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
